#!/usr/bin/env python3
"""
BTC Widget Server - 本地HTTP服务器，提供币安永续合约分析
端口: 8765
"""

import json
import threading
import os
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import urlparse, parse_qs
from urllib.request import urlopen
from urllib.error import URLError
import urllib.request
import time

BINANCE_BASE = "https://fapi.binance.com"

def smart_round(v, sig=5):
    """根据价格大小自动决定小数位，避免小价格显示0.00"""
    if v == 0:
        return 0
    import math
    digits = sig - int(math.floor(math.log10(abs(v)))) - 1
    digits = max(2, min(digits, 10))
    return round(v, digits)




# 中文名 -> 交易对 映射（用户搜中文时自动补全）
CN_NAME_MAP = {
    "比特币": "BTC", "以太坊": "ETH", "以太": "ETH",
    "索拉纳": "SOL", "狗狗币": "DOGE", "柴犬": "SHIB",
    "波卡": "DOT", "链接": "LINK", "雪崩": "AVAX",
    "波场": "TRX", "莱特币": "LTC", "币安币": "BNB",
    "人生": "NIGHT", "夜晚": "NIGHT",
    "OP": "OP", "ARB": "ARB", "PEPE": "PEPE",
    "土狗": "", "聪明钱": "", "鲨鱼": "DOGE",
}

HIGHER_INTERVAL = {
    "5m": "15m",
    "15m": "1h",
    "1h": "4h",
    "4h": "1d",
    "1d": "1w"
}


def binance_get(path, params=None, timeout=4):
    """所有对binance的请求走这里，timeout严格限制，Windows下用socket超时双保险"""
    url = BINANCE_BASE + path
    if params:
        from urllib.parse import urlencode
        url += "?" + urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "btc-widget/1.0"})
    import socket
    old_timeout = socket.getdefaulttimeout()
    try:
        socket.setdefaulttimeout(timeout)
        with urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    finally:
        socket.setdefaulttimeout(old_timeout)


def get_symbols():
    data = binance_get("/fapi/v1/exchangeInfo")
    syms = [s["symbol"] for s in data["symbols"] if s["contractType"] == "PERPETUAL" and s["status"] == "TRADING"]
    # 部分合约symbol含中文（如"币安人生USDT"），正常返回即可
    return syms


def get_klines(symbol, interval, limit=120):
    data = binance_get("/fapi/v1/klines", {"symbol": symbol, "interval": interval, "limit": str(limit)})
    closes  = [float(k[4]) for k in data]
    highs   = [float(k[2]) for k in data]
    lows    = [float(k[3]) for k in data]
    volumes = [float(k[5]) for k in data]
    return closes, highs, lows, volumes


def calc_ema(prices, period):
    ema = []
    k = 2 / (period + 1)
    for i, p in enumerate(prices):
        if i == 0:
            ema.append(p)
        else:
            ema.append(p * k + ema[-1] * (1 - k))
    return ema


def calc_rsi(closes, period=14):
    if len(closes) < period + 1:
        return 50.0
    gains, losses = [], []
    for i in range(1, len(closes)):
        d = closes[i] - closes[i - 1]
        gains.append(max(d, 0))
        losses.append(max(-d, 0))
    ag = sum(gains[-period:]) / period
    al = sum(losses[-period:]) / period
    if al == 0:
        return 100.0
    rs = ag / al
    return 100 - 100 / (1 + rs)


def calc_atr(highs, lows, closes, period=14):
    trs = []
    for i in range(1, len(closes)):
        tr = max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]), abs(lows[i] - closes[i - 1]))
        trs.append(tr)
    if not trs:
        return 0.0
    return sum(trs[-period:]) / min(len(trs), period)


ATR_BUF = {"5m": 0.35, "15m": 0.35, "1h": 0.5, "4h": 0.8, "1d": 0.8, "1w": 0.8}


def analyze_trend(closes, highs, lows, interval="15m"):
    """趋势分析：使用已收盘K线（忽略最后一根），EMA20/55，趋势强度过滤"""
    # 忽略最后一根未收盘K线
    c = closes[:-1]
    h = highs[:-1]
    l = lows[:-1]

    if len(c) < 56:
        return None  # 数据不足

    ema20 = calc_ema(c, 20)
    ema55 = calc_ema(c, 55)
    rsi   = calc_rsi(c)
    atr   = calc_atr(h, l, c)

    price = c[-1]
    e20   = ema20[-1]
    e55   = ema55[-1]

    # 趋势方向
    if price > e20 > e55:
        raw_trend = "多"
    elif price < e20 < e55:
        raw_trend = "空"
    else:
        raw_trend = "中性"

    # 趋势强度过滤：EMA间距必须 >= ATR*0.2
    ema_gap = abs(e20 - e55)
    ema_strong = (atr > 0) and (ema_gap >= atr * 0.2)
    trend = raw_trend if ema_strong else "中性"

    # 价格结构（最近5根，基于已收盘）
    r_highs = h[-5:]
    r_lows  = l[-5:]
    structure_up = (r_highs[-1] > r_highs[0]) or (r_lows[-1] > r_lows[0])
    structure_dn = (r_highs[-1] < r_highs[0]) or (r_lows[-1] < r_lows[0])
    if trend == "多":
        structure_ok = structure_up
    elif trend == "空":
        structure_ok = structure_dn
    else:
        structure_ok = False

    # 量能（用K线成交量，不额外请求接口）
    vol_ok = False  # 默认False，需要volumes参数，这里占位

    # 支撑阻力
    sorted_lows  = sorted(l[-20:])
    sorted_highs = sorted(h[-20:])
    support    = sum(sorted_lows[:3])  / 3
    resistance = sum(sorted_highs[-3:]) / 3

    # 状态描述
    if rsi > 70:
        state = "超买"
    elif rsi < 30:
        state = "超卖"
    elif trend == "多" and rsi > 50:
        state = "多头延续"
    elif trend == "空" and rsi < 50:
        state = "空头延续"
    elif trend == "多":
        state = "多头偏弱"
    elif trend == "空":
        state = "空头偏弱"
    else:
        state = "震荡"

    return {
        "trend":        trend,
        "raw_trend":    raw_trend,
        "ema_strong":   ema_strong,
        "ema_gap":      round(ema_gap, 6),
        "structure_ok": structure_ok,
        "rsi":          round(rsi, 2),
        "atr":          atr,
        "support":      smart_round(support),
        "resistance":   smart_round(resistance),
        "state":        state,
        "current_price": smart_round(price),
        "ema20":        smart_round(e20),
        "ema55":        smart_round(e55),
    }


def get_oi_change(symbol):
    try:
        data = binance_get("/futures/data/openInterestHist", {
            "symbol": symbol, "period": "5m", "limit": "2"
        })
        if len(data) >= 2:
            oi_now = float(data[-1]["sumOpenInterestValue"])
            oi_prev = float(data[-2]["sumOpenInterestValue"])
            if oi_prev > 0:
                return round((oi_now - oi_prev) / oi_prev * 100, 4)
    except Exception:
        pass
    return 0.0


def get_taker_ratio(symbol):
    try:
        data = binance_get("/futures/data/takerlongshortRatio", {
            "symbol": symbol, "period": "5m", "limit": "1"
        })
        if data:
            return round(float(data[-1]["buySellRatio"]), 4)
    except Exception:
        pass
    return 1.0


def get_top_position_ratio(symbol):
    try:
        data = binance_get("/futures/data/topLongShortPositionRatio", {
            "symbol": symbol, "period": "5m", "limit": "1"
        })
        if data:
            return round(float(data[-1]["longShortRatio"]), 4)
    except Exception:
        pass
    return 1.0


def get_funding_rate(symbol):
    try:
        data = binance_get("/fapi/v1/premiumIndex", {"symbol": symbol})
        return round(float(data["lastFundingRate"]), 8)
    except Exception:
        pass
    return 0.0


def analyze(symbol, interval):
    closes, highs, lows, volumes = get_klines(symbol, interval, limit=80)
    chart = [smart_round(c) for c in closes[-60:]]

    current = analyze_trend(closes, highs, lows, interval)
    if not current:
        return {"symbol": symbol, "error": "数据不足"}

    current_price = current["current_price"]
    atr           = current["atr"]
    trend         = current["trend"]
    rsi           = current["rsi"]

    # 量能（用已收盘成交量）
    vols    = volumes[:-1]
    vol_ma10 = sum(vols[-10:]) / min(len(vols), 10)
    recent3  = vols[-3:]
    vol_ok   = sum(1 for v in recent3 if v > vol_ma10 * 1.1) >= 2

    # 上级周期
    higher_interval = HIGHER_INTERVAL.get(interval, "1d")
    h_closes, h_highs, h_lows, _ = get_klines(symbol, higher_interval, limit=70)
    higher = analyze_trend(h_closes, h_highs, h_lows, higher_interval)
    higher_trend = higher["trend"] if higher else "中性"

    # 链上数据（详情页保留）
    oi_change = get_oi_change(symbol)
    taker     = get_taker_ratio(symbol)
    top_pos   = get_top_position_ratio(symbol)
    last_fr   = get_funding_rate(symbol)

    fr_status = "偏多" if last_fr > 0.0005 else ("偏空" if last_fr < -0.0005 else "中性")

    # 信号评分
    _, direction_label, signal_score, higher_ok = _score_signal(
        trend, higher_trend, current["ema_strong"], current["structure_ok"], vol_ok, interval
    )

    # 止损止盈（近端5根结构止损，再判档）
    support    = current["support"]
    resistance = current["resistance"]
    entry      = current_price
    highs5     = highs[:-1][-5:]   # 最近5根已收盘高点
    lows5      = lows[:-1][-5:]    # 最近5根已收盘低点
    atr_buf    = ATR_BUF.get(interval, 0.3)

    if trend == "多":
        sl_anchor     = min(lows5)
        stop_loss_raw = sl_anchor - atr * atr_buf
        risk          = max(abs(entry - stop_loss_raw), atr * 0.3)
        space         = max(resistance - entry, atr * 1.0) if resistance > entry else atr * 1.0
    elif trend == "空":
        sl_anchor     = max(highs5)
        stop_loss_raw = sl_anchor + atr * atr_buf
        risk          = max(abs(stop_loss_raw - entry), atr * 0.3)
        space         = max(entry - support, atr * 1.0) if support < entry else atr * 1.0
    else:
        stop_loss_raw = None
        risk  = atr * 0.3
        space = atr * 1.0

    # RR用动态TP模型(max(risk*1.2, atr*0.8))判断分档
    tp1_dist_for_grade = max(risk * 1.2, atr * 0.8)
    rr_for_grade = round(tp1_dist_for_grade / risk, 2) if risk > 0 else 0.0

    # 交易成本过滤（基于TP1最终距离）
    cost      = entry * 0.0008 * 2 + atr * 0.05
    tp2_dist_for_grade = max(risk * 2.0, atr * 1.6)
    cost_ok   = (tp1_dist_for_grade > cost * 2) and (tp2_dist_for_grade > cost * 3)

    # 分档
    if direction_label in ("逆势观察", "观察") or trend == "中性":
        signal_grade = "C"
    elif signal_score >= 3 and space >= atr * 1.0 and rr_for_grade >= 1.4 and cost_ok:
        signal_grade = "A"
    elif signal_score >= 2 and higher_ok and space >= atr * 0.7 and rr_for_grade >= 1.1 and cost_ok:
        signal_grade = "B"
    else:
        signal_grade = "C"

    # 计算最终止盈止损（传入highs5/lows5以使用近端止损）
    stop_loss_final, tp1, tp2, tp3, _, _, rr = _calc_tp_sl(
        trend, entry, support, resistance, atr, interval, signal_grade,
        highs5=highs5, lows5=lows5
    )
    entry_price = smart_round(entry) if signal_grade in ("A", "B") else None
    stop_loss   = stop_loss_final

    # ---- v10 增强字段 ----
    ap_score, ap_reasons = _a_plus_score(trend, closes, highs, lows, atr,
                                         current["ema_strong"], risk, signal_grade)
    is_aplus = (
        (signal_grade == "A" and ap_score >= 3) or
        (signal_grade == "B" and ap_score >= 4 and rr_for_grade >= 1.2)
    )
    pos_sug = _position_suggestion(signal_grade, rr_for_grade, risk, atr, ap_score)
    dur_bars, dur_text = _signal_duration(symbol, interval, trend, signal_grade)
    # 更新模拟统计
    _sim_update(symbol, interval, signal_grade, trend,
                entry_price, stop_loss, tp1, tp2, rr_for_grade,
                closes[-10:])
    # ---- end v10 ----

    # 动态保护提示
    if tp1 and stop_loss:
        protect_tips = (
            f"到达TP1({tp1})后将止损移至保本价({smart_round(entry)})；"
            f"到达TP2({tp2})后将止损移至TP1({tp1})"
        )
    else:
        protect_tips = "当前无开单方案，无需保护"
    protection_status = "未触发"

    # 大白话
    reasons_plain = []
    if higher_trend == "多":
        reasons_plain.append(f"大方向（{higher_interval}）：偏多，大均线向上，价格在上方")
    elif higher_trend == "空":
        reasons_plain.append(f"大方向（{higher_interval}）：偏空，大均线向下，价格在下方")
    else:
        reasons_plain.append(f"大方向（{higher_interval}）：中性，均线纠缠，方向不明")

    momentum = "偏强" if rsi > 55 else ("偏弱" if rsi < 45 else "中性")
    reasons_plain.append(f"当前盘面（{interval}）：{current['state']}，RSI {rsi:.0f}，动能{momentum}")

    if current["ema_strong"]:
        reasons_plain.append(f"EMA趋势明确：EMA20({current['ema20']})与EMA55({current['ema55']})间距充分，趋势确立")
    else:
        reasons_plain.append(f"EMA趋势偏弱：EMA20与EMA55过近，可能处于震荡，信号可信度低")

    if vol_ok:
        reasons_plain.append("量能放大：最近3根K中有2根以上成交量高于均值，资金在推动")
    else:
        reasons_plain.append("量能不足：最近成交量低于均值，缺乏资金推动")

    if current["structure_ok"]:
        reasons_plain.append(f"结构方向明确：高低点{'递增' if trend=='多' else '递减'}，结构支持{'做多' if trend=='多' else '做空'}")
    else:
        reasons_plain.append("结构不明：高低点方向不一致，结构信号弱")

    oi_desc    = "新资金进场" if oi_change > 0.2 else ("仓位在撤退" if oi_change < -0.2 else "仓位平稳")
    taker_desc = "主动买盘强" if taker > 1.05 else ("主动砸盘强" if taker < 0.95 else "买卖力量相当")
    top_desc   = "大户偏多" if top_pos > 1.05 else ("大户偏空" if top_pos < 0.95 else "大户中性")
    reasons_plain.append(f"链上：OI{oi_change:+.2f}%({oi_desc})，Taker{taker:.3f}({taker_desc})，大户{top_pos:.3f}({top_desc})")
    reasons_plain.append(f"资金费率：{last_fr*100:.4f}%，{fr_status}")

    if signal_grade == "A":
        summary = f"【A档】方向明确，空间充足，RR={rr}，可以考虑入场"
    elif signal_grade == "B":
        summary = f"【B档】大周期顺势，条件基本满足，RR={rr}，可轻仓试探"
    elif direction_label == "逆势观察":
        summary = f"【C档-逆势】当前{interval}偏{trend}但大周期({higher_interval})偏{higher_trend}，不建议开单"
    else:
        summary = f"【C档-观察】条件未达标（评分{signal_score}/4，空间{round(space/atr,2) if atr>0 else 0}ATR，RR{rr_for_grade}），不开单"
    reasons_plain.append(summary)

    return {
        "symbol":           symbol,
        "interval":         interval,
        "close":            smart_round(current_price),
        "trend":            trend,
        "signal_grade":     signal_grade,
        "direction_label":  direction_label,
        "signal_score":     signal_score,
        "rsi":              rsi,
        "atr":              smart_round(atr),
        "support":          smart_round(support),
        "resistance":       smart_round(resistance),
        "state":            current["state"],
        "ema_strong":       current["ema_strong"],
        "structure_ok":     current["structure_ok"],
        "vol_ok":           vol_ok,
        "higher_interval":  higher_interval,
        "higher_trend":     higher_trend,
        "space":            smart_round(space),
        "rr":               rr if signal_grade in ("A","B") else rr_for_grade,
        "summary":          summary,
        "reasons_plain":    reasons_plain,
        "oi_change":        oi_change,
        "taker_ratio":      taker,
        "top_pos_ratio":    top_pos,
        "last_funding_rate": last_fr,
        "funding_state":    fr_status,
        "entry_price":      entry_price,
        "stop_loss":        smart_round(stop_loss) if stop_loss else None,
        "tp1":              smart_round(tp1) if tp1 else None,
        "tp2":              smart_round(tp2) if tp2 else None,
        "tp3":              smart_round(tp3) if tp3 else None,
        "protection_status": protection_status,
        "protect_tips":     protect_tips,
        "chart":            chart,
        "timestamp":        int(time.time()),
        # v10 新增字段
        "a_plus_score":           ap_score,
        "a_plus_reasons":         ap_reasons,
        "is_aplus":               is_aplus,
        "position_suggestion":    pos_sug,
        "signal_duration_bars":   dur_bars,
        "signal_duration_text":   dur_text,
    }


# ========== v10 信号增强层 ==========

# 信号持续时间追踪（内存态，重启归零，不做持久化）
_signal_tracker = {}

def _a_plus_score(trend, closes, highs, lows, atr, ema_strong, risk, signal_grade):
    """A+ 优选评分 0-5 分，只对 A/B 档调用"""
    if signal_grade not in ("A", "B"):
        return 0, []
    score = 0; reasons = []
    c = closes[:-1]; h = highs[:-1]; l = lows[:-1]
    price = c[-1]
    def ema_f(p,n):
        k=2/(n+1);e=p[0]
        for v in p[1:]: e=v*k+e*(1-k)
        return e
    e20 = ema_f(c, 20)
    # 1. 延迟确认：前一根K方向与趋势一致
    if len(c) >= 2:
        prev_bull = c[-1] > c[-2]
        if (trend=="多" and prev_bull) or (trend=="空" and not prev_bull):
            score += 1; reasons.append("延迟确认✓")
    # 2. 趋势强度
    if ema_strong:
        score += 1; reasons.append("趋势强✓")
    # 3. 位置合理：偏离EMA20 < ATR*0.5
    if atr > 0 and abs(price - e20) < atr * 0.5:
        score += 1; reasons.append("位置好✓")
    # 4. 非追单：最近K振幅 < ATR*1.2
    if len(h) >= 1 and atr > 0 and (h[-1] - l[-1]) < atr * 1.2:
        score += 1; reasons.append("非追单✓")
    # 5. 结构质量：risk <= ATR*1.0
    if atr > 0 and risk <= atr * 1.0:
        score += 1; reasons.append("结构清晰✓")
    return score, reasons


def _position_suggestion(signal_grade, rr_for_grade, risk, atr, a_plus_sc):
    """仓位建议，展示字段，不影响信号生成"""
    if signal_grade == "C":
        return "谨慎观望"
    if signal_grade == "A" and a_plus_sc >= 3 and rr_for_grade >= 1.3 and risk <= atr * 1.0:
        return "标准仓位"
    return "轻仓试探"


def _signal_duration(symbol, interval, trend, signal_grade):
    """内存追踪信号持续K数，返回 (bars, text)"""
    key = (symbol, interval, trend, signal_grade)
    now = int(time.time())
    entry = _signal_tracker.get(key)
    if entry:
        entry["bars"] += 1; entry["last_seen"] = now
    else:
        for k in list(_signal_tracker.keys()):
            if k[0] == symbol and k[1] == interval and k != key:
                del _signal_tracker[k]
        _signal_tracker[key] = {"bars": 1, "first_seen": now, "last_seen": now}
        entry = _signal_tracker[key]
    bars = entry["bars"]
    bar_mins = {"1m":1,"3m":3,"5m":5,"15m":15,"30m":30,"1h":60,"4h":240,"1d":1440}.get(interval,15)
    mins = bars * bar_mins
    if mins < 60:
        text = f"持续约{mins}分钟"
    else:
        h_, m_ = divmod(mins, 60)
        text = f"持续约{h_}小时{m_}分钟" if m_ else f"持续约{h_}小时"
    return bars, f"第{bars}根K · {text}"


# ========== 模拟统计 ==========
_sim_log = []   # 最近50条 A/B 信号快照

def _sim_update(symbol, interval, signal_grade, trend, entry, sl, tp1, tp2, rr, closes_recent):
    """追加/结算模拟信号记录"""
    global _sim_log
    if signal_grade not in ("A","B"):
        return
    now = int(time.time())
    # 结算旧未结算记录
    for rec in _sim_log:
        if rec["symbol"]==symbol and rec["result"] is None and rec["entry"] and rec["sl"] and rec["tp1"]:
            e=float(rec["entry"]); s=float(rec["sl"]); t1=float(rec["tp1"])
            for cv in closes_recent:
                if rec["trend"]=="多":
                    if cv>=t1: rec["result"]="tp1"; break
                    if cv<=s:  rec["result"]="sl";  break
                else:
                    if cv<=t1: rec["result"]="tp1"; break
                    if cv>=s:  rec["result"]="sl";  break
    # 同币同方向同档位不重复追加
    last = next((r for r in reversed(_sim_log) if r["symbol"]==symbol and r["interval"]==interval), None)
    if last and last["trend"]==trend and last["signal_grade"]==signal_grade:
        return
    _sim_log.append({"symbol":symbol,"interval":interval,"signal_grade":signal_grade,
                     "trend":trend,"entry":entry,"sl":sl,"tp1":tp1,"tp2":tp2,
                     "rr":rr,"ts":now,"result":None})
    if len(_sim_log) > 50:
        _sim_log = _sim_log[-50:]


def get_sim_stats():
    """返回模拟统计概览"""
    total = len(_sim_log)
    if total == 0:
        return {"total":0,"win_rate":None,"tp1_rate":None,"sl_rate":None,
                "avg_rr":None,"long_count":0,"short_count":0,"pending":0,
                "note":"暂无信号记录（服务启动后自动积累）"}
    settled = [r for r in _sim_log if r["result"] is not None]
    pending = total - len(settled)
    tp1_hits = sum(1 for r in settled if r["result"]=="tp1")
    sl_hits  = sum(1 for r in settled if r["result"]=="sl")
    rrs = [float(r["rr"]) for r in _sim_log if r.get("rr") is not None]
    return {
        "total":       total,
        "pending":     pending,
        "win_rate":    round(tp1_hits/len(settled)*100,1) if settled else None,
        "tp1_rate":    round(tp1_hits/len(settled)*100,1) if settled else None,
        "sl_rate":     round(sl_hits /len(settled)*100,1) if settled else None,
        "avg_rr":      round(sum(rrs)/len(rrs),2) if rrs else None,
        "long_count":  sum(1 for r in _sim_log if r["trend"]=="多"),
        "short_count": sum(1 for r in _sim_log if r["trend"]=="空"),
        "note":        f"已记录{total}条，{len(settled)}条已结算，{pending}条待结算",
    }


def _score_signal(trend, higher_trend, ema_strong, structure_ok, vol_ok, interval):
    """统一信号评分逻辑（analyze和_layer2_full共用）
    返回：signal_grade, direction_label, signal_score, higher_ok
    """
    higher_ok = (trend == higher_trend and trend != "中性")
    opposite  = (trend != "中性" and higher_trend != "中性" and trend != higher_trend)

    if opposite:
        return "C", "逆势观察", 0, False

    if trend == "中性":
        return "C", "观察", 0, False

    ema_ok       = ema_strong
    signal_score = sum([higher_ok, ema_ok, structure_ok, vol_ok])

    direction_label = "做多" if trend == "多" else "做空"
    # 暂返回score，分档在调用方做（需要space/RR）
    return None, direction_label, signal_score, higher_ok


def _calc_tp_sl(trend, entry, support, resistance, atr, interval, signal_grade,
                highs5=None, lows5=None):
    """统一止损止盈计算，返回 stop_loss, tp1, tp2, tp3, risk, space, rr
    止损：近5根K线结构（近端止损）
    止盈：risk动态模型 + ATR最小底线 max(risk×倍数, ATR×底线)
    """
    atr_buf = ATR_BUF.get(interval, 0.3)

    if trend == "多":
        sl_anchor = min(lows5) if lows5 else support
        stop_loss = smart_round(sl_anchor - atr * atr_buf)
        risk      = max(abs(entry - stop_loss), atr * 0.3)
        space     = max(resistance - entry, atr * 1.0) if resistance > entry else atr * 1.0
    elif trend == "空":
        sl_anchor = max(highs5) if highs5 else resistance
        stop_loss = smart_round(sl_anchor + atr * atr_buf)
        risk      = max(abs(stop_loss - entry), atr * 0.3)
        space     = max(entry - support, atr * 1.0) if support < entry else atr * 1.0
    else:
        return None, None, None, None, atr * 0.3, atr * 1.0, 0.0

    if signal_grade not in ("A", "B"):
        return None, None, None, None, risk, space, 0.0

    # 动态止盈：以risk为主，但不能低于ATR最小底线
    tp1_dist = max(risk * 1.2, atr * 0.8)
    tp2_dist = max(risk * 2.0, atr * 1.6)
    tp3_dist = max(risk * 3.0, atr * 2.5)

    if trend == "多":
        tp1 = smart_round(entry + tp1_dist)
        tp2 = smart_round(entry + tp2_dist)
        tp3 = smart_round(entry + tp3_dist)
    else:
        tp1 = smart_round(entry - tp1_dist)
        tp2 = smart_round(entry - tp2_dist)
        tp3 = smart_round(entry - tp3_dist)

    rr_val = round(tp1_dist / risk, 2) if risk > 0 else 0.0
    return stop_loss, tp1, tp2, tp3, risk, space, rr_val

def _layer1_filter(top_n=50):
    """第一层：1次请求拿全市场数据，筛出候选池（无K线请求）
    top_n 控制主通道数量，bonus通道固定10个（高波动补充）
    """
    tickers = binance_get("/fapi/v1/ticker/24hr", timeout=8)
    candidates = []
    for t in tickers:
        sym = t["symbol"]
        if not sym.endswith("USDT"):
            continue
        try:
            qvol = float(t["quoteVolume"])
            price = float(t["lastPrice"])
            change_pct = float(t["priceChangePercent"])
            high = float(t["highPrice"])
            low = float(t["lowPrice"])
            if price <= 0 or low <= 0:
                continue
            volatility = (high - low) / low * 100
            candidates.append({
                "symbol": sym,
                "price": price,
                "qvol": qvol,
                "change_pct": change_pct,
                "volatility": volatility,
            })
        except Exception:
            continue

    if not candidates:
        return []

    by_vol = sorted(candidates, key=lambda x: -x["qvol"])
    # 主通道：按top_n取（真正响应参数）
    main_pool = by_vol[:top_n]
    main_syms = {c["symbol"] for c in main_pool}

    # 补漏通道：高波动但不在主通道，固定限10个（大幅缩减）
    bonus = [c for c in by_vol[top_n:] if c["volatility"] > 8.0][:10]

    return main_pool + bonus


def _layer2_full(symbol, interval, ticker_data=None):
    """第二层：与详情页同一套算法，只拉K线，量能用成交量"""
    try:
        kl = binance_get("/fapi/v1/klines", {"symbol": symbol, "interval": interval, "limit": "65"}, timeout=4)
        closes  = [float(k[4]) for k in kl]
        highs   = [float(k[2]) for k in kl]
        lows    = [float(k[3]) for k in kl]
        volumes = [float(k[5]) for k in kl]

        higher_interval = HIGHER_INTERVAL.get(interval, "1d")
        hkl = binance_get("/fapi/v1/klines", {"symbol": symbol, "interval": higher_interval, "limit": "65"}, timeout=4)
        h_closes = [float(k[4]) for k in hkl]
        h_highs  = [float(k[2]) for k in hkl]
        h_lows   = [float(k[3]) for k in hkl]

        current = analyze_trend(closes, highs, lows, interval)
        higher  = analyze_trend(h_closes, h_highs, h_lows, higher_interval)
        if not current or not higher:
            return None

        trend        = current["trend"]
        higher_trend = higher["trend"]
        atr          = current["atr"]

        # 量能（已收盘成交量）
        vols     = volumes[:-1]
        vol_ma10 = sum(vols[-10:]) / min(len(vols), 10)
        vol_ok   = sum(1 for v in vols[-3:] if v > vol_ma10 * 1.1) >= 2

        _, direction_label, signal_score, higher_ok = _score_signal(
            trend, higher_trend, current["ema_strong"], current["structure_ok"], vol_ok, interval
        )

        support    = current["support"]
        resistance = current["resistance"]
        entry      = current["current_price"]
        highs5     = highs[:-1][-5:]  # 近5根已收盘高点
        lows5      = lows[:-1][-5:]   # 近5根已收盘低点
        atr_buf    = ATR_BUF.get(interval, 0.3)

        # 近端止损计算
        if trend == "多":
            sl_anchor = min(lows5)
            risk = max(abs(entry - (sl_anchor - atr * atr_buf)), atr * 0.3)
            space = max(resistance - entry, atr * 1.0) if resistance > entry else atr * 1.0
        elif trend == "空":
            sl_anchor = max(highs5)
            risk = max(abs((sl_anchor + atr * atr_buf) - entry), atr * 0.3)
            space = max(entry - support, atr * 1.0) if support < entry else atr * 1.0
        else:
            risk = atr * 0.3
            space = atr * 1.0

        tp1_dist_g = max(risk * 1.2, atr * 0.8)
        tp2_dist_g = max(risk * 2.0, atr * 1.6)
        rr_for_grade = round(tp1_dist_g / risk, 2) if risk > 0 else 0.0
        cost       = entry * 0.0008 * 2 + atr * 0.05
        cost_ok    = (tp1_dist_g > cost * 2) and (tp2_dist_g > cost * 3)

        if direction_label in ("逆势观察", "观察") or trend == "中性":
            signal_grade = "C"
        elif signal_score >= 3 and space >= atr * 1.0 and rr_for_grade >= 1.4 and cost_ok:
            signal_grade = "A"
        elif signal_score >= 2 and higher_ok and space >= atr * 0.7 and rr_for_grade >= 1.1 and cost_ok:
            signal_grade = "B"
        else:
            signal_grade = "C"

        result = {
            "symbol":         symbol,
            "close":          smart_round(entry),
            "trend":          trend,
            "signal_grade":   signal_grade,
            "direction_label": direction_label,
            "score":          signal_score,
            "rsi":            round(current["rsi"], 1),
            "higher_trend":   higher_trend,
            "space":          smart_round(space),
            "rr":             rr_for_grade if signal_grade in ("A","B") else None,
            "atr":            smart_round(atr),
        }
        # v10：为扫描层追加 A+/仓位/持续时间
        if signal_grade in ("A", "B"):
            ap_sc, ap_rs = _a_plus_score(trend, closes, highs, lows, atr,
                                         current["ema_strong"], risk, signal_grade)
            is_ap = (signal_grade=="A" and ap_sc>=3) or (signal_grade=="B" and ap_sc>=4 and rr_for_grade>=1.2)
            dur_b, dur_t = _signal_duration(symbol, interval, trend, signal_grade)
            pos_s = _position_suggestion(signal_grade, rr_for_grade, risk, atr, ap_sc)
            result.update({
                "a_plus_score":        ap_sc,
                "a_plus_reasons":      ap_rs,
                "is_aplus":            is_ap,
                "position_suggestion": pos_s,
                "signal_duration_bars": dur_b,
                "signal_duration_text": dur_t,
            })
        else:
            result.update({
                "a_plus_score": 0, "a_plus_reasons": [],
                "is_aplus": False,
                "position_suggestion": "谨慎观望",
                "signal_duration_bars": None, "signal_duration_text": None,
            })
        if ticker_data:
            result["change_pct"] = round(ticker_data.get("change_pct", 0), 2)
            result["qvol"]       = ticker_data.get("qvol", 0)
        return result
    except Exception:
        return None


def get_overview(interval="15m", top_n=50):
    """扫描：首页A/B进主区，C进观察区"""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    try:
        candidates = _layer1_filter(top_n)
    except Exception:
        candidates = []

    if not candidates:
        return {
            "interval": interval, "total_scanned": 0,
            "longs": [], "shorts": [], "longs_watch": [], "shorts_watch": [],
            "timestamp": int(time.time())
        }

    ticker_map = {c["symbol"]: c for c in candidates}
    results = []
    with ThreadPoolExecutor(max_workers=20) as ex:
        futures = {
            ex.submit(_layer2_full, sym, interval, ticker_map.get(sym)): sym
            for sym in ticker_map
        }
        for f in as_completed(futures, timeout=45):
            try:
                r = f.result()
                if r:
                    results.append(r)
            except Exception:
                pass

    grade_order = {"A": 3, "B": 2, "C": 1}

    def sort_key(x):
        return (-grade_order.get(x["signal_grade"], 0), -(x.get("space") or 0), -(x.get("rr") or 0))

    longs        = sorted([r for r in results if r["trend"] == "多"  and r["signal_grade"] in ("A","B")], key=sort_key)
    shorts       = sorted([r for r in results if r["trend"] == "空"  and r["signal_grade"] in ("A","B")], key=sort_key)
    longs_watch  = sorted([r for r in results if r["trend"] == "多"  and r["signal_grade"] == "C"],        key=sort_key)
    shorts_watch = sorted([r for r in results if r["trend"] == "空"  and r["signal_grade"] == "C"],        key=sort_key)

    # v10：构建 A+ 优选列表（从所有 A/B 结果中筛选）
    aplus_list = sorted(
        [r for r in results if r.get("is_aplus")],
        key=lambda x: (-x.get("a_plus_score", 0), -(x.get("rr") or 0))
    )

    return {
        "interval":      interval,
        "total_scanned": len(ticker_map),
        "longs":         longs,
        "shorts":        shorts,
        "longs_watch":   longs_watch,
        "shorts_watch":  shorts_watch,
        "aplus":         aplus_list,
        "sim_stats":     get_sim_stats(),
        "timestamp":     int(time.time()),
    }


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """多线程HTTP服务器：每个请求独立线程，扫描不阻塞其他请求"""
    daemon_threads = True


class WidgetHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # 静默日志

    def send_json(self, data, status=200):
        # ensure_ascii=True 避免中文字符导致Content-Length计算错误
        body = json.dumps(data, ensure_ascii=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_text(self, text, status=200):
        body = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_html(self, html, status=200):
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        if path == "/health":
            self.send_text("ok")

        elif path == "/":
            # 返回UI
            # v10_dev：使用开发版 UI
            ui_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "widget_ui.html")
            if os.path.exists(ui_path):
                with open(ui_path, "r", encoding="utf-8") as f:
                    html = f.read()
                self.send_html(html)
            else:
                self.send_text("widget_ui.html not found", 404)

        elif path == "/api/symbols":
            try:
                symbols = get_symbols()
                # 加入中文别名，方便搜索
                cn_entries = []
                for cn, en in CN_NAME_MAP.items():
                    if en:
                        matches = [s for s in symbols if s.startswith(en+'USDT') or s == en+'USDT']
                        for m in matches:
                            cn_entries.append({"symbol": m, "cn": cn})
                # 把含中文的symbol也加进cn_entries
                for s in symbols:
                    if any('一' <= c <= '鿿' for c in s):
                        cn_entries.append({"symbol": s, "cn": s})
                self.send_json({"symbols": symbols, "cn_map": cn_entries})
            except Exception as e:
                self.send_json({"error": str(e)}, 500)

        elif path == "/api/overview":
            interval = params.get("interval", ["15m"])[0]
            top_n = int(params.get("top_n", ["50"])[0])
            try:
                result = get_overview(interval, top_n)
                self.send_json(result)
            except Exception as e:
                import traceback
                self.send_json({"error": str(e), "trace": traceback.format_exc()}, 500)

        elif path == "/api/analyze":
            symbol = params.get("symbol", ["BTCUSDT"])[0].upper()
            interval = params.get("interval", ["15m"])[0]
            try:
                result = analyze(symbol, interval)
                self.send_json(result)
            except Exception as e:
                import traceback
                self.send_json({"error": str(e), "trace": traceback.format_exc()}, 500)

        else:
            self.send_text("Not Found", 404)


def run_server(port=8765, host="0.0.0.0"):
    server = ThreadedHTTPServer((host, port), WidgetHandler)
    import socket
    local_ip = socket.gethostbyname(socket.gethostname())
    print(f"[BTC Widget] Server running at http://0.0.0.0:{port} (多线程模式)")
    print(f"[BTC Widget] 本机访问: http://127.0.0.1:{port}")
    print(f"[BTC Widget] 局域网访问: http://{local_ip}:{port}")
    server.serve_forever()
    server.serve_forever()


def launch_with_pywebview(port=8765):
    import webview
    window = webview.create_window(
        "BTC Widget",
        f"http://127.0.0.1:{port}",
        width=900,
        height=900,
        resizable=True,
    )
    webview.start()


def launch_with_tkinter_fallback():
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.title("BTC Widget - 缺少依赖")
        root.geometry("400x200")
        label = tk.Label(
            root,
            text="请安装 pywebview 以使用桌面窗口模式：\n\npip install pywebview\n\n或直接浏览器访问：\nhttp://127.0.0.1:8765",
            justify="center",
            pady=20,
        )
        label.pack(expand=True)
        btn = tk.Button(root, text="关闭", command=root.destroy)
        btn.pack(pady=10)
        root.mainloop()
    except Exception:
        print("请安装 pywebview: pip install pywebview")
        print("或直接浏览器访问: http://127.0.0.1:8765")


if __name__ == "__main__":
    PORT = 8765

    # 先启动服务器线程
    t = threading.Thread(target=run_server, args=(PORT,), daemon=True)
    t.start()
    time.sleep(0.5)  # 等待服务器就绪

    # 尝试 pywebview 启动
    try:
        import webview
        print("[BTC Widget] 使用 pywebview 桌面窗口")
        launch_with_pywebview(PORT)
    except ImportError:
        print("[BTC Widget] 未安装 pywebview，使用 tkinter 提示")
        launch_with_tkinter_fallback()
        # tkinter 退出后，服务器仍在后台，保持主线程存活
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n[BTC Widget] 已停止")
