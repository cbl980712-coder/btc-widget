#!/usr/bin/env python3
"""
BTC Widget Server - 本地HTTP服务器，提供币安永续合约分析
端口: 8765
"""

import json
import threading
import os
import sys
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import urlparse, parse_qs
from urllib.request import urlopen
from urllib.error import URLError
import urllib.request
import time

BINANCE_BASE = "https://fapi.binance.com"

def smart_round(v, sig=5):
    """根据价格大小自动决定小数位，避免小价格显示0.00"""
    if v == 0:
        return 0
    import math
    digits = sig - int(math.floor(math.log10(abs(v)))) - 1
    digits = max(2, min(digits, 10))
    return round(v, digits)




# 中文名 -> 交易对 映射（用户搜中文时自动补全）
CN_NAME_MAP = {
    "比特币": "BTC", "以太坊": "ETH", "以太": "ETH",
    "索拉纳": "SOL", "狗狗币": "DOGE", "柴犬": "SHIB",
    "波卡": "DOT", "链接": "LINK", "雪崩": "AVAX",
    "波场": "TRX", "莱特币": "LTC", "币安币": "BNB",
    "人生": "NIGHT", "夜晚": "NIGHT",
    "OP": "OP", "ARB": "ARB", "PEPE": "PEPE",
    "土狗": "", "聪明钱": "", "鲨鱼": "DOGE",
}

HIGHER_INTERVAL = {
    "5m": "15m",
    "15m": "1h",
    "1h": "4h",
    "4h": "1d",
    "1d": "1w"
}

# ===== 执行层常量 =====
# 15m 改归 trade 模型（允许主交易单）
TRADE_STYLE = {"5m": "scalp", "15m": "trade", "1h": "trade", "4h": "trade", "1d": "trade"}

INVALID_BARS = {"5m": 3, "15m": 3, "1h": 2, "4h": 2, "1d": 1}

SL_PCT_LIMIT = {"scalp": 3.0, "trade": 5.0}

# market直进的sl_pct上限
MARKET_SL_LIMIT = {"5m": 1.5, "15m": 1.8, "1h": 2.5}  # 4h/1d不允许market

EXPECTED_HOLD = {
    "5m":  "15分钟 ~ 1.5小时",
    "15m": "30分钟 ~ 3小时",
    "1h":  "2小时 ~ 12小时",
    "4h":  "半天 ~ 2天",
    "1d":  "1天 ~ 5天",
}

# TP/SL 两套模型参数
# scalp（仅5m）：旧模型
SCALP_MIN_RISK_ATR  = 0.3
SCALP_TP1_RISK_MULT = 1.2;  SCALP_TP2_RISK_MULT = 2.0;  SCALP_TP3_RISK_MULT = 3.0
SCALP_TP1_ATR_FLOOR = 0.8;  SCALP_TP2_ATR_FLOOR = 1.6;  SCALP_TP3_ATR_FLOOR = 2.5
# trade（15m/1h/4h/1d）：新模型
TRADE_MIN_RISK_ATR  = {"5m": 0.3, "15m": 1.0, "1h": 1.0, "4h": 1.2, "1d": 1.2}
TRADE_TP1_RISK_MULT = 1.5;  TRADE_TP2_RISK_MULT = 2.5;  TRADE_TP3_RISK_MULT = 4.0
TRADE_TP1_ATR_FLOOR = 1.1;  TRADE_TP2_ATR_FLOOR = 1.8;  TRADE_TP3_ATR_FLOOR = 3.0

# 进场锁定期（active后禁止失效判断的K线数）
LOCK_BARS = {"5m": 2, "15m": 2, "1h": 1, "4h": 1, "1d": 1}

# ===== signal_state 追踪器（内存态，重启归零；字段全为基础类型，便于后续JSON持久化） =====
_signal_tracker = {}

def _tracker_key(symbol, interval, trend, signal_grade):
    return (symbol, interval, trend, signal_grade)

def _tracker_get(symbol, interval, trend, signal_grade):
    return _signal_tracker.get(_tracker_key(symbol, interval, trend, signal_grade))

def _tracker_init(symbol, interval, trend, signal_grade, entry_type, entry_zone, entry_confirm):
    """初始化或更新 tracker（pending时累计bar_count；已active/closed不重置）"""
    key = _tracker_key(symbol, interval, trend, signal_grade)
    now = int(time.time())
    rec = _signal_tracker.get(key)
    if rec and rec.get("state") in ("pending", "active"):
        rec["entry_zone"]    = entry_zone if rec["state"] == "pending" else rec.get("entry_zone")
        rec["entry_confirm"] = entry_confirm if rec["state"] == "pending" else rec.get("entry_confirm")
        rec["entry_type"]    = entry_type if rec["state"] == "pending" else rec.get("entry_type")
        rec["bar_count"]     = rec.get("bar_count", 0) + 1
        return rec
    _signal_tracker[key] = {
        "state":            "pending",
        "first_seen_ts":    now,
        "active_ts":        None,
        "entry_trigger_ts": None,
        "lock_bars":        LOCK_BARS.get(interval, 1),
        "lock_until_bar":   None,
        "bar_count":        1,
        "closed_reason":    None,
        "entry_zone":       entry_zone,
        "entry_confirm":    entry_confirm,
        "entry_type":       entry_type,
        # 执行窗口：信号进入A/B主区后的冻结期，期间软条件变化不导致下架
        "exec_window_bars": LOCK_BARS.get(interval, 2),  # 复用 LOCK_BARS 常量
        "exec_window_until": None,  # bar_count <= 此值时处于执行窗口内
    }
    return _signal_tracker[key]

def _tracker_try_activate(symbol, interval, trend, signal_grade, market_price):
    """若 pending 信号价格满足进场条件则切换 active"""
    key = _tracker_key(symbol, interval, trend, signal_grade)
    rec = _signal_tracker.get(key)
    if not rec or rec["state"] != "pending":
        return rec
    et, zone, conf = rec.get("entry_type","pullback"), rec.get("entry_zone"), rec.get("entry_confirm")
    now = int(time.time())
    triggered = False
    if et == "market":
        triggered = True
    elif et == "pullback" and zone:
        # 执行窗口内容忍度放宽至 ±0.2ATR（由 zone 宽度隐含，这里直接判断 ±10% zone 宽度容忍）
        triggered = (zone[0] <= market_price <= zone[1])
    elif et == "breakout" and conf is not None:
        triggered = (market_price >= conf) if trend == "多" else (market_price <= conf)
    if triggered:
        rec["state"]             = "active"
        rec["active_ts"]         = now
        rec["entry_trigger_ts"]  = now
        rec["lock_until_bar"]    = rec["bar_count"] + rec["lock_bars"]
        rec["exec_window_until"] = rec["bar_count"] + rec.get("exec_window_bars", 2)
    return rec

def _is_hard_stale(rec, market_price, atr, trend):
    """执行窗口内只允许硬失效条件让信号下架
    硬失效 = 价格明确破坏 entry_zone 或 breakout 跑远
    软变化（趋势变弱/RSI/结构）在窗口内不算失效
    返回 (is_stale: bool, reason: str)
    """
    if not rec:
        return False, ""
    bar_count = rec.get("bar_count", 0)
    exec_until = rec.get("exec_window_until")
    in_window = (exec_until is not None and bar_count <= exec_until)
    et   = rec.get("entry_type", "pullback")
    zone = rec.get("entry_zone")
    conf = rec.get("entry_confirm")

    if in_window:
        # 窗口内：只检查硬失效
        if et == "pullback" and zone:
            lo, hi = zone
            # 硬失效：价格明确超出失效线（比容忍区间更远）
            # 做多：price < zone[0] - atr*0.5（被明确破坏）
            # 做空：price > zone[1] + atr*0.5
            if trend == "多" and market_price < lo - atr * 0.5:
                return True, f"执行窗口内价格跌破进场区间下沿（失效线），硬失效"
            if trend == "空" and market_price > hi + atr * 0.5:
                return True, f"执行窗口内价格突破进场区间上沿（失效线），硬失效"
        elif et == "breakout" and conf is not None:
            if trend == "多" and market_price > conf + atr * 0.25:
                return True, f"breakout后价格偏离确认位超过0.25ATR，已跑远"
            if trend == "空" and market_price < conf - atr * 0.25:
                return True, f"breakout后价格偏离确认位超过0.25ATR，已跑远"
        # 其他软变化在窗口内全部忽略，不失效
        return False, ""
    else:
        # 窗口结束后：执行窗口耗尽仍未入场 → 失效
        if rec["state"] == "pending":
            invalid_bars = rec.get("lock_bars", 2)  # 重用 lock_bars 作为 invalid_bars
            if bar_count > invalid_bars:
                return True, f"执行窗口结束，已超{invalid_bars}根K线仍未触发入场"
        return False, ""

def _tracker_close(symbol, interval, trend, signal_grade, reason):
    key = _tracker_key(symbol, interval, trend, signal_grade)
    rec = _signal_tracker.get(key)
    if rec:
        rec["state"] = "closed"; rec["closed_reason"] = reason

def _position_management(trend, market_price, entry_price, stop_loss, tp1, tp2, tp3):
    """active 阶段仓位管理：只用价格触发，绝不输出失效相关内容"""
    if not all([entry_price, stop_loss, tp1]):
        return {"action": "持仓观察", "detail": "等待价格信号"}
    risk = abs(entry_price - stop_loss)
    if risk <= 0:
        return {"action": "持仓观察", "detail": "止损设置异常，请检查"}
    be_trigger = (entry_price + risk * 0.8) if trend == "多" else (entry_price - risk * 0.8)
    r_pct = lambda p: round(abs(p - entry_price) / risk * 100, 0)
    if trend == "多":
        if market_price <= stop_loss:
            return {"action": "⚠️ 止损", "detail": f"当前价{market_price} ≤ 止损{stop_loss}，建议立即止损"}
        if tp3 and market_price >= tp3:
            return {"action": "🎯 TP3达标", "detail": f"当前价{market_price}≥TP3 {tp3}，可全平或趋势持有"}
        if tp2 and market_price >= tp2:
            return {"action": "🎯 TP2达标", "detail": f"当前价{market_price}≥TP2 {tp2}，止损上移至TP1 {tp1}，余仓持有"}
        if market_price >= tp1:
            return {"action": "🎯 TP1达标", "detail": f"当前价{market_price}≥TP1 {tp1}，建议减仓30-50%，止损上移至入场价{smart_round(entry_price)}"}
        if market_price >= be_trigger:
            return {"action": "📍 移本建议", "detail": f"浮盈{r_pct(market_price):.0f}%R，建议止损上移至入场价{smart_round(entry_price)}"}
        return {"action": "持仓观察", "detail": f"持仓中，浮动{r_pct(market_price):.0f}%R，止损在{stop_loss}"}
    else:
        if market_price >= stop_loss:
            return {"action": "⚠️ 止损", "detail": f"当前价{market_price} ≥ 止损{stop_loss}，建议立即止损"}
        if tp3 and market_price <= tp3:
            return {"action": "🎯 TP3达标", "detail": f"当前价{market_price}≤TP3 {tp3}，可全平或趋势持有"}
        if tp2 and market_price <= tp2:
            return {"action": "🎯 TP2达标", "detail": f"当前价{market_price}≤TP2 {tp2}，止损下移至TP1 {tp1}，余仓持有"}
        if market_price <= tp1:
            return {"action": "🎯 TP1达标", "detail": f"当前价{market_price}≤TP1 {tp1}，建议减仓30-50%，止损下移至入场价{smart_round(entry_price)}"}
        if market_price <= be_trigger:
            return {"action": "📍 移本建议", "detail": f"浮盈{r_pct(market_price):.0f}%R，建议止损下移至入场价{smart_round(entry_price)}"}
        return {"action": "持仓观察", "detail": f"持仓中，浮动{r_pct(market_price):.0f}%R，止损在{stop_loss}"}


def _calc_entry_model(trend, entry, atr, interval, signal_grade, higher_trend,
                      support, resistance, signal_age_bars, tp1, stop_loss,
                      entry_type_override=None):
    """计算进场模型：entry_type / entry_zone / entry_confirm / execution_tag 等
    entry_type_override: 由 analyze() 根据 prev_close 传入 'breakout'，否则默认 pullback
    """
    trade_style = TRADE_STYLE.get(interval, "intraday")
    invalid_bars = INVALID_BARS.get(interval, 2)
    expected_hold = EXPECTED_HOLD.get(interval, "--")

    # tp1_pct / sl_pct
    tp1_pct = round(abs(tp1 - entry) / entry * 100, 3) if tp1 and entry else None
    sl_pct  = round(abs(stop_loss - entry) / entry * 100, 3) if stop_loss and entry else None
    rr_real = round(abs(tp1 - entry) / abs(stop_loss - entry), 2) if (tp1 and stop_loss and abs(stop_loss - entry) > 0) else None

    # ---- 判断 entry_type ----
    # 1. breakout：前一根已收盘K线是否突破 support/resistance
    #    (调用处传入 prev_close，这里用 resistance/support 与 entry 比较近似判断)
    #    更精确：由 analyze() 层传入 closes[-2]（前一根收盘）
    # 先默认 pullback，后面细化
    entry_type = "pullback"
    entry_zone_basis = "atr_pullback"
    entry_confirm = None

    if trend == "空":
        # breakout 做空：前一根收盘 < support（已跌破支撑）
        entry_confirm_candidate = smart_round(support - atr * 0.17)
        entry_type = "pullback"   # 默认回踩，breakout由外层传 prev_close 覆盖
        entry_zone = [smart_round(entry), smart_round(entry + atr * 0.3)]
        entry_zone_invalid_price = smart_round(entry + atr * 0.5)
        entry_zone_basis = "atr_pullback"
    elif trend == "多":
        entry_confirm_candidate = smart_round(resistance + atr * 0.17)
        entry_type = "pullback"
        entry_zone = [smart_round(entry - atr * 0.3), smart_round(entry)]
        entry_zone_invalid_price = smart_round(entry - atr * 0.5)
        entry_zone_basis = "atr_pullback"
    else:
        return None

    # market 白名单（严格条件）
    sl_pct_limit_market = MARKET_SL_LIMIT.get(interval)
    can_market = (
        signal_grade == "A"
        and higher_trend == trend
        and signal_age_bars == 0
        and tp1_pct is not None and tp1_pct >= 1.2
        and sl_pct is not None
        and sl_pct_limit_market is not None
        and sl_pct <= sl_pct_limit_market
        and trade_style != "swing"
    )
    if can_market:
        entry_type = "market"
        entry_zone_basis = "market_direct"
        entry_zone = [smart_round(entry), smart_round(entry)]

    # ---- execution_tag 优先级链（命中即停止）----
    stale_signal = signal_age_bars > invalid_bars

    # 新增：容忍度判断（轻仓路径允许轻微偏离）
    # pullback：当前价在 entry_zone ± 0.2ATR 内 → 允许轻仓
    # breakout：偏离 entry_confirm ≤ 0.3ATR → 允许轻仓
    near_entry = False
    if entry_type == "pullback" and entry_zone:
        lo, hi = entry_zone
        near_entry = (lo - atr * 0.2 <= entry <= hi + atr * 0.2)
    elif entry_type == "breakout":
        ec = entry_confirm_candidate
        if ec is not None:
            near_entry = (abs(entry - ec) <= atr * 0.3)
    elif entry_type == "market":
        near_entry = True

    # 级1：已失效（严格失效：age超限 且 偏离容忍度也超了）
    if stale_signal and not near_entry:
        tag = "已失效"
        reason = f"信号已持续{signal_age_bars}根K线（上限{invalid_bars}根），当前价也已偏离进场区间"
    elif stale_signal and near_entry:
        # age超限但价格仍在容忍范围 → 降级为轻仓而不是直接失效
        tag = "轻仓试单"
        reason = f"信号持续{signal_age_bars}根K线（稍超上限{invalid_bars}根），但当前价仍接近进场区间，可轻仓参与"
        stale_signal = False  # 不进入归档区
    # 级2：风险过高
    elif (sl_pct is not None) and (sl_pct > SL_PCT_LIMIT.get(trade_style, 3.0)):
        tag = "风险过高"
        reason = f"止损幅度{sl_pct:.2f}%，超过{trade_style}上限{SL_PCT_LIMIT.get(trade_style,3.0):.1f}%"
    # 级3：仅观察（tp1太小）
    elif tp1_pct is not None and tp1_pct < 0.6:
        tag = "仅观察"
        reason = f"TP1仅{tp1_pct:.2f}%，利润空间偏小，建议等待更好机会"
    # 级4/5：按 trade_style + tp1_pct 分类
    else:
        waiting_tag = ("等待回踩" if entry_type == "pullback" else
                       "等待突破确认" if entry_type == "breakout" else None)

        if trade_style == "scalp":
            tag = waiting_tag if waiting_tag else "轻仓试单"
            reason = (f"scalp快线，TP1 {tp1_pct:.2f}%，严控仓位，等待进入区间后轻仓"
                      if waiting_tag else f"scalp快线，TP1 {tp1_pct:.2f}%，严控仓位，快进快出")
        else:  # trade / intraday / swing
            rr_ok = (rr_real is not None and rr_real >= 1.1)
            tp_ok = (tp1_pct is not None and tp1_pct >= 1.2)
            if tp_ok and rr_ok and not waiting_tag:
                tag = "主交易单"
                reason = f"TP1 {tp1_pct:.2f}%，止损{sl_pct:.2f}%，RR={rr_real}，时效与结构均通过"
            elif tp1_pct is not None and tp1_pct >= 0.6 and rr_ok:
                tag = waiting_tag if waiting_tag else "轻仓试单"
                reason = (f"TP1 {tp1_pct:.2f}%，等待进入区间后轻仓参与" if waiting_tag
                          else f"TP1 {tp1_pct:.2f}%，RR={rr_real}，空间尚可，轻仓试探")
            elif waiting_tag:
                tag = waiting_tag
                reason = f"TP1 {tp1_pct:.2f}%，等待{tag[2:]}后参与"
            else:
                tag = "轻仓试单"
                reason = f"TP1 {tp1_pct:.2f}%，结构有效，轻仓参考"

    return {
        "entry_type":               entry_type,
        "entry_zone":               entry_zone,
        "entry_zone_basis":         entry_zone_basis,
        "entry_zone_invalid_price": entry_zone_invalid_price,
        "entry_zone_invalid_bars":  invalid_bars,
        "entry_confirm":            entry_confirm_candidate if entry_type == "breakout" else None,
        "tp1_pct":                  tp1_pct,
        "sl_pct":                   sl_pct,
        "rr_real":                  rr_real,
        "trade_style":              trade_style,
        "execution_tag":            tag,
        "execution_reason":         reason,
        "signal_age_bars":          signal_age_bars,
        "stale_signal":             stale_signal,
        "expected_hold_time":       expected_hold,
    }


def binance_get(path, params=None, timeout=4):
    """所有对binance的请求走这里，timeout严格限制，Windows下用socket超时双保险"""
    url = BINANCE_BASE + path
    if params:
        from urllib.parse import urlencode
        url += "?" + urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "btc-widget/1.0"})
    import socket
    old_timeout = socket.getdefaulttimeout()
    try:
        socket.setdefaulttimeout(timeout)
        with urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    finally:
        socket.setdefaulttimeout(old_timeout)


def get_symbols():
    data = binance_get("/fapi/v1/exchangeInfo")
    syms = [s["symbol"] for s in data["symbols"] if s["contractType"] == "PERPETUAL" and s["status"] == "TRADING"]
    # 部分合约symbol含中文（如"币安人生USDT"），正常返回即可
    return syms


def get_klines(symbol, interval, limit=120):
    data = binance_get("/fapi/v1/klines", {"symbol": symbol, "interval": interval, "limit": str(limit)})
    closes  = [float(k[4]) for k in data]
    highs   = [float(k[2]) for k in data]
    lows    = [float(k[3]) for k in data]
    volumes = [float(k[5]) for k in data]
    return closes, highs, lows, volumes


def calc_ema(prices, period):
    ema = []
    k = 2 / (period + 1)
    for i, p in enumerate(prices):
        if i == 0:
            ema.append(p)
        else:
            ema.append(p * k + ema[-1] * (1 - k))
    return ema


def calc_rsi(closes, period=14):
    if len(closes) < period + 1:
        return 50.0
    gains, losses = [], []
    for i in range(1, len(closes)):
        d = closes[i] - closes[i - 1]
        gains.append(max(d, 0))
        losses.append(max(-d, 0))
    ag = sum(gains[-period:]) / period
    al = sum(losses[-period:]) / period
    if al == 0:
        return 100.0
    rs = ag / al
    return 100 - 100 / (1 + rs)


def calc_atr(highs, lows, closes, period=14):
    trs = []
    for i in range(1, len(closes)):
        tr = max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]), abs(lows[i] - closes[i - 1]))
        trs.append(tr)
    if not trs:
        return 0.0
    return sum(trs[-period:]) / min(len(trs), period)


ATR_BUF = {"5m": 0.35, "15m": 0.35, "1h": 0.5, "4h": 0.8, "1d": 0.8, "1w": 0.8}


def analyze_trend(closes, highs, lows, interval="15m"):
    """趋势分析：使用已收盘K线（忽略最后一根），EMA20/55，趋势强度过滤"""
    # 忽略最后一根未收盘K线
    c = closes[:-1]
    h = highs[:-1]
    l = lows[:-1]

    if len(c) < 56:
        return None  # 数据不足

    ema20 = calc_ema(c, 20)
    ema55 = calc_ema(c, 55)
    rsi   = calc_rsi(c)
    atr   = calc_atr(h, l, c)

    price = c[-1]
    e20   = ema20[-1]
    e55   = ema55[-1]

    # 趋势方向
    if price > e20 > e55:
        raw_trend = "多"
    elif price < e20 < e55:
        raw_trend = "空"
    else:
        raw_trend = "中性"

    # 趋势强度过滤：EMA间距必须 >= ATR*0.2
    ema_gap = abs(e20 - e55)
    ema_strong = (atr > 0) and (ema_gap >= atr * 0.2)
    trend = raw_trend if ema_strong else "中性"

    # 价格结构（最近5根，基于已收盘）
    r_highs = h[-5:]
    r_lows  = l[-5:]
    structure_up = (r_highs[-1] > r_highs[0]) or (r_lows[-1] > r_lows[0])
    structure_dn = (r_highs[-1] < r_highs[0]) or (r_lows[-1] < r_lows[0])
    if trend == "多":
        structure_ok = structure_up
    elif trend == "空":
        structure_ok = structure_dn
    else:
        structure_ok = False

    # 量能（用K线成交量，不额外请求接口）
    vol_ok = False  # 默认False，需要volumes参数，这里占位

    # 支撑阻力
    sorted_lows  = sorted(l[-20:])
    sorted_highs = sorted(h[-20:])
    support    = sum(sorted_lows[:3])  / 3
    resistance = sum(sorted_highs[-3:]) / 3

    # 状态描述
    if rsi > 70:
        state = "超买"
    elif rsi < 30:
        state = "超卖"
    elif trend == "多" and rsi > 50:
        state = "多头延续"
    elif trend == "空" and rsi < 50:
        state = "空头延续"
    elif trend == "多":
        state = "多头偏弱"
    elif trend == "空":
        state = "空头偏弱"
    else:
        state = "震荡"

    return {
        "trend":        trend,
        "raw_trend":    raw_trend,
        "ema_strong":   ema_strong,
        "ema_gap":      round(ema_gap, 6),
        "structure_ok": structure_ok,
        "rsi":          round(rsi, 2),
        "atr":          atr,
        "support":      smart_round(support),
        "resistance":   smart_round(resistance),
        "state":        state,
        "current_price": smart_round(price),
        "ema20":        smart_round(e20),
        "ema55":        smart_round(e55),
    }


def get_oi_change(symbol):
    try:
        data = binance_get("/futures/data/openInterestHist", {
            "symbol": symbol, "period": "5m", "limit": "2"
        })
        if len(data) >= 2:
            oi_now = float(data[-1]["sumOpenInterestValue"])
            oi_prev = float(data[-2]["sumOpenInterestValue"])
            if oi_prev > 0:
                return round((oi_now - oi_prev) / oi_prev * 100, 4)
    except Exception:
        pass
    return 0.0


def get_taker_ratio(symbol):
    try:
        data = binance_get("/futures/data/takerlongshortRatio", {
            "symbol": symbol, "period": "5m", "limit": "1"
        })
        if data:
            return round(float(data[-1]["buySellRatio"]), 4)
    except Exception:
        pass
    return 1.0


def get_top_position_ratio(symbol):
    try:
        data = binance_get("/futures/data/topLongShortPositionRatio", {
            "symbol": symbol, "period": "5m", "limit": "1"
        })
        if data:
            return round(float(data[-1]["longShortRatio"]), 4)
    except Exception:
        pass
    return 1.0


def get_funding_rate(symbol):
    try:
        data = binance_get("/fapi/v1/premiumIndex", {"symbol": symbol})
        return round(float(data["lastFundingRate"]), 8)
    except Exception:
        pass
    return 0.0


def get_market_price(symbol):
    """拉取统一市场价（markPrice），用于所有执行层计算，不依赖K线周期"""
    try:
        data = binance_get("/fapi/v1/premiumIndex", {"symbol": symbol}, timeout=3)
        p = float(data.get("markPrice", 0))
        return p if p > 0 else None
    except Exception:
        return None


def analyze(symbol, interval):
    closes, highs, lows, volumes = get_klines(symbol, interval, limit=80)
    chart = [smart_round(c) for c in closes[-60:]]

    current = analyze_trend(closes, highs, lows, interval)
    if not current:
        return {"symbol": symbol, "error": "数据不足"}

    kline_close   = current["current_price"]   # 该周期K线收盘价（仅用于趋势/ATR/结构）
    atr           = current["atr"]
    trend         = current["trend"]
    rsi           = current["rsi"]

    # 统一市场价（markPrice）—— 所有执行层计算基准
    market_price = get_market_price(symbol)
    if market_price is None:
        market_price = kline_close  # 降级：markPrice失败时用K线close
    market_price = smart_round(market_price)

    # 量能（用已收盘成交量）
    vols    = volumes[:-1]
    vol_ma10 = sum(vols[-10:]) / min(len(vols), 10)
    recent3  = vols[-3:]
    vol_ok   = sum(1 for v in recent3 if v > vol_ma10 * 1.1) >= 2

    # 上级周期
    higher_interval = HIGHER_INTERVAL.get(interval, "1d")
    h_closes, h_highs, h_lows, _ = get_klines(symbol, higher_interval, limit=70)
    higher = analyze_trend(h_closes, h_highs, h_lows, higher_interval)
    higher_trend = higher["trend"] if higher else "中性"

    # 链上数据（详情页保留）
    oi_change = get_oi_change(symbol)
    taker     = get_taker_ratio(symbol)
    top_pos   = get_top_position_ratio(symbol)
    last_fr   = get_funding_rate(symbol)

    fr_status = "偏多" if last_fr > 0.0005 else ("偏空" if last_fr < -0.0005 else "中性")

    # 信号评分
    _, direction_label, signal_score, higher_ok = _score_signal(
        trend, higher_trend, current["ema_strong"], current["structure_ok"], vol_ok, interval
    )

    # 止损止盈（近端5根结构止损，再判档）
    # entry 统一使用 market_price（不再用K线周期close）
    support    = current["support"]
    resistance = current["resistance"]
    entry      = market_price          # ← 统一市场价作为执行基准
    highs5     = highs[:-1][-5:]       # 最近5根已收盘高点（结构判断用）
    lows5      = lows[:-1][-5:]        # 最近5根已收盘低点
    atr_buf    = ATR_BUF.get(interval, 0.3)

    if trend == "多":
        sl_anchor     = min(lows5)
        stop_loss_raw = sl_anchor - atr * atr_buf
        risk          = max(abs(entry - stop_loss_raw), atr * 0.3)
        space         = max(resistance - entry, atr * 1.0) if resistance > entry else atr * 1.0
    elif trend == "空":
        sl_anchor     = max(highs5)
        stop_loss_raw = sl_anchor + atr * atr_buf
        risk          = max(abs(stop_loss_raw - entry), atr * 0.3)
        space         = max(entry - support, atr * 1.0) if support < entry else atr * 1.0
    else:
        stop_loss_raw = None
        risk  = atr * 0.3
        space = atr * 1.0

    # RR用动态TP模型(max(risk*1.2, atr*0.8))判断分档
    tp1_dist_for_grade = max(risk * 1.2, atr * 0.8)
    rr_for_grade = round(tp1_dist_for_grade / risk, 2) if risk > 0 else 0.0

    # 交易成本过滤（基于TP1最终距离）
    cost      = entry * 0.0008 * 2 + atr * 0.05
    tp2_dist_for_grade = max(risk * 2.0, atr * 1.6)
    cost_ok   = (tp1_dist_for_grade > cost * 2) and (tp2_dist_for_grade > cost * 3)

    # 分档
    if direction_label in ("逆势观察", "观察") or trend == "中性":
        signal_grade = "C"
    elif signal_score >= 3 and space >= atr * 1.0 and rr_for_grade >= 1.4 and cost_ok:
        signal_grade = "A"
    elif signal_score >= 2 and higher_ok and space >= atr * 0.7 and rr_for_grade >= 1.1 and cost_ok:
        signal_grade = "B"
    else:
        signal_grade = "C"

    # 计算最终止盈止损（entry=market_price，SL锚点用K线结构）
    stop_loss_final, tp1, tp2, tp3, _, _, rr = _calc_tp_sl(
        trend, entry, support, resistance, atr, interval, signal_grade,
        highs5=highs5, lows5=lows5
    )
    entry_price = smart_round(entry) if signal_grade in ("A", "B") else None
    stop_loss   = stop_loss_final

    # ---- v10 增强字段 ----
    ap_score, ap_reasons = _a_plus_score(trend, closes, highs, lows, atr,
                                         current["ema_strong"], risk, signal_grade)
    is_aplus = (
        (signal_grade == "A" and ap_score >= 3) or
        (signal_grade == "B" and ap_score >= 4 and rr_for_grade >= 1.2)
    )
    pos_sug = _position_suggestion(signal_grade, rr_for_grade, risk, atr, ap_score)
    dur_bars, dur_text = _signal_duration(symbol, interval, trend, signal_grade)
    # 更新旧模拟统计（保留兼容）
    _sim_update(symbol, interval, signal_grade, trend,
                entry_price, stop_loss, tp1, tp2, rr_for_grade,
                closes[-10:])
    # Phase A：策略统计 tick（先用 high/low 推进已有记录的状态机）
    if highs and lows and len(highs) >= 1 and len(lows) >= 1:
        _strategy_tick(symbol, interval, float(highs[-1]), float(lows[-1]), int(time.time()))

    # ---- 执行层：进场模型 + signal_state ----
    entry_model    = None
    signal_state   = "none"
    position_mgmt  = None
    in_exec_window = False

    if signal_grade in ("A", "B") and entry_price and stop_loss and tp1:
        age_bars = dur_bars - 1 if dur_bars and dur_bars > 0 else 0

        # 先算 entry_model（含 entry_type / entry_zone 等）
        entry_model = _calc_entry_model(
            trend, entry, atr, interval, signal_grade, higher_trend,
            support, resistance, age_bars, tp1, stop_loss
        )
        # breakout 判断（前一根K线是否已突破关键位）
        prev_close = closes[-2] if len(closes) >= 2 else None
        if entry_model and prev_close:
            if trend == "空" and prev_close < support:
                entry_model["entry_type"] = "breakout"
                entry_model["entry_zone_basis"] = "support_breakout_confirm"
                entry_model["entry_confirm"] = smart_round(support - atr * 0.17)
            elif trend == "多" and prev_close > resistance:
                entry_model["entry_type"] = "breakout"
                entry_model["entry_zone_basis"] = "resistance_breakout_confirm"
                entry_model["entry_confirm"] = smart_round(resistance + atr * 0.17)

        et   = entry_model["entry_type"] if entry_model else "pullback"
        zone = entry_model.get("entry_zone") if entry_model else None
        conf = entry_model.get("entry_confirm") if entry_model else None

        # 初始化/更新 tracker（第一次进A/B区时自动设置 exec_window_until）
        rec = _tracker_init(symbol, interval, trend, signal_grade, et, zone, conf)
        # 首次进入：设置执行窗口截止bar
        if rec.get("exec_window_until") is None:
            rec["exec_window_until"] = rec["bar_count"] + rec.get("exec_window_bars", 2)

        # pending：尝试自动进入 active
        if rec["state"] == "pending":
            rec = _tracker_try_activate(symbol, interval, trend, signal_grade, market_price)

        signal_state   = rec["state"]
        bar_count      = rec.get("bar_count", 0)
        exec_until     = rec.get("exec_window_until", 0)
        in_exec_window = (bar_count <= exec_until)

        if signal_state == "active":
            # ★ active：彻底绕开失效判断，只运行仓位管理
            position_mgmt = _position_management(
                trend, market_price, entry_price, stop_loss, tp1, tp2, tp3
            )
            if position_mgmt["action"].startswith("⚠️ 止损"):
                _tracker_close(symbol, interval, trend, signal_grade, "sl_hit")
                signal_state = "closed"
            elif position_mgmt["action"].startswith("🎯 TP3"):
                _tracker_close(symbol, interval, trend, signal_grade, "tp3_hit")
                signal_state = "closed"
            if entry_model:
                entry_model["stale_signal"]     = False
                entry_model["execution_tag"]    = f"持仓中 · {position_mgmt['action']}"
                entry_model["execution_reason"] = position_mgmt["detail"]

        elif signal_state == "pending":
            # ★ pending：使用硬失效检查（执行窗口内只允许硬条件失效）
            hard_stale, hard_reason = _is_hard_stale(rec, market_price, atr, trend)
            if hard_stale:
                if entry_model:
                    entry_model["stale_signal"]     = True
                    entry_model["execution_tag"]    = "已失效"
                    entry_model["execution_reason"] = hard_reason
            else:
                if entry_model:
                    entry_model["stale_signal"] = False
            # Phase A：非失效的 pending 信号注册到策略统计
            if entry_model and not entry_model.get("stale_signal"):
                _strategy_record(
                    symbol, interval, signal_grade, entry_model.get("execution_tag",""),
                    trend, entry_price, stop_loss, tp1, tp2, tp3,
                    round(abs(tp1-entry_price)/abs(stop_loss-entry_price),2) if (tp1 and stop_loss and abs(stop_loss-entry_price)>0) else None
                )
            # Phase B：模拟自动交易——尝试开仓（pending 信号触发入场时）
            if entry_model and not entry_model.get("stale_signal"):
                exec_tag_b = entry_model.get("execution_tag","")
                if exec_tag_b in ("主交易单","轻仓试单") and signal_state != "active":
                    # 开仓（重复开仓由 _sim_open_position 内部过滤）
                    _sim_open_position(
                        symbol, interval, trend, et,
                        entry_price, stop_loss, tp1, tp2, tp3,
                        signal_grade, exec_tag_b, market_price, strategy="main"
                    )
                    # 反向策略同步开仓（mode=reverse 或 both）
                    rev = _calc_reverse_signal(trend, entry_price, stop_loss, tp1, tp2, tp3)
                    if rev and _sim_account["config"].get("mode") in ("reverse","both"):
                        _sim_open_position(
                            symbol, interval, rev["trend"], et,
                            rev["entry"], rev["sl"], rev["tp1"], rev["tp2"], rev["tp3"],
                            signal_grade, exec_tag_b, market_price, strategy="reverse"
                        )
            # 对 active 信号也推进已有仓位的 tick（价格已进场时持续管理）
            if market_price and highs and lows and len(highs) >= 1:
                _sim_tick_positions(symbol, interval, float(highs[-1]), float(lows[-1]), market_price, int(time.time()))

    # ---- end v10 ----

    # 动态保护提示
    if tp1 and stop_loss:
        protect_tips = (
            f"到达TP1({tp1})后将止损移至保本价({smart_round(entry)})；"
            f"到达TP2({tp2})后将止损移至TP1({tp1})"
        )
    else:
        protect_tips = "当前无开单方案，无需保护"
    protection_status = "未触发"

    # 大白话
    reasons_plain = []
    if higher_trend == "多":
        reasons_plain.append(f"大方向（{higher_interval}）：偏多，大均线向上，价格在上方")
    elif higher_trend == "空":
        reasons_plain.append(f"大方向（{higher_interval}）：偏空，大均线向下，价格在下方")
    else:
        reasons_plain.append(f"大方向（{higher_interval}）：中性，均线纠缠，方向不明")

    momentum = "偏强" if rsi > 55 else ("偏弱" if rsi < 45 else "中性")
    reasons_plain.append(f"当前盘面（{interval}）：{current['state']}，RSI {rsi:.0f}，动能{momentum}")

    if current["ema_strong"]:
        reasons_plain.append(f"EMA趋势明确：EMA20({current['ema20']})与EMA55({current['ema55']})间距充分，趋势确立")
    else:
        reasons_plain.append(f"EMA趋势偏弱：EMA20与EMA55过近，可能处于震荡，信号可信度低")

    if vol_ok:
        reasons_plain.append("量能放大：最近3根K中有2根以上成交量高于均值，资金在推动")
    else:
        reasons_plain.append("量能不足：最近成交量低于均值，缺乏资金推动")

    if current["structure_ok"]:
        reasons_plain.append(f"结构方向明确：高低点{'递增' if trend=='多' else '递减'}，结构支持{'做多' if trend=='多' else '做空'}")
    else:
        reasons_plain.append("结构不明：高低点方向不一致，结构信号弱")

    oi_desc    = "新资金进场" if oi_change > 0.2 else ("仓位在撤退" if oi_change < -0.2 else "仓位平稳")
    taker_desc = "主动买盘强" if taker > 1.05 else ("主动砸盘强" if taker < 0.95 else "买卖力量相当")
    top_desc   = "大户偏多" if top_pos > 1.05 else ("大户偏空" if top_pos < 0.95 else "大户中性")
    reasons_plain.append(f"链上：OI{oi_change:+.2f}%({oi_desc})，Taker{taker:.3f}({taker_desc})，大户{top_pos:.3f}({top_desc})")
    reasons_plain.append(f"资金费率：{last_fr*100:.4f}%，{fr_status}")

    if signal_grade == "A":
        summary = f"【A档】方向明确，空间充足，RR={rr}，可以考虑入场"
    elif signal_grade == "B":
        summary = f"【B档】大周期顺势，条件基本满足，RR={rr}，可轻仓试探"
    elif direction_label == "逆势观察":
        summary = f"【C档-逆势】当前{interval}偏{trend}但大周期({higher_interval})偏{higher_trend}，不建议开单"
    else:
        summary = f"【C档-观察】条件未达标（评分{signal_score}/4，空间{round(space/atr,2) if atr>0 else 0}ATR，RR{rr_for_grade}），不开单"
    reasons_plain.append(summary)

    return {
        "symbol":           symbol,
        "interval":         interval,
        "close":            smart_round(kline_close),    # K线周期收盘价（趋势/ATR信号计算基准）
        "market_price":     market_price,                # 统一市场价（markPrice，执行层基准）
        "trend":            trend,
        "signal_grade":     signal_grade,
        "direction_label":  direction_label,
        "signal_score":     signal_score,
        "rsi":              rsi,
        "atr":              smart_round(atr),
        "support":          smart_round(support),
        "resistance":       smart_round(resistance),
        "state":            current["state"],
        "ema_strong":       current["ema_strong"],
        "structure_ok":     current["structure_ok"],
        "vol_ok":           vol_ok,
        "higher_interval":  higher_interval,
        "higher_trend":     higher_trend,
        "space":            smart_round(space),
        "rr":               rr if signal_grade in ("A","B") else rr_for_grade,
        "summary":          summary,
        "reasons_plain":    reasons_plain,
        "oi_change":        oi_change,
        "taker_ratio":      taker,
        "top_pos_ratio":    top_pos,
        "last_funding_rate": last_fr,
        "funding_state":    fr_status,
        "entry_price":      entry_price,
        "stop_loss":        smart_round(stop_loss) if stop_loss else None,
        "tp1":              smart_round(tp1) if tp1 else None,
        "tp2":              smart_round(tp2) if tp2 else None,
        "tp3":              smart_round(tp3) if tp3 else None,
        "protection_status": protection_status,
        "protect_tips":     protect_tips,
        "chart":            chart,
        "timestamp":        int(time.time()),
        # v10 新增字段
        "a_plus_score":           ap_score,
        "a_plus_reasons":         ap_reasons,
        "is_aplus":               is_aplus,
        "position_suggestion":    pos_sug,
        "signal_duration_bars":   dur_bars,
        "signal_duration_text":   dur_text,
        # 执行层
        "entry_model":            entry_model,
        "signal_state":           signal_state,
        "in_exec_window":         in_exec_window,
        "position_mgmt":          position_mgmt,
    }


# ========== v10 信号增强层 ==========

# 信号持续时间追踪（独立 dict，不与 signal_state tracker 混用）
_dur_tracker = {}

def _a_plus_score(trend, closes, highs, lows, atr, ema_strong, risk, signal_grade):
    """A+ 优选评分 0-5 分，只对 A/B 档调用"""
    if signal_grade not in ("A", "B"):
        return 0, []
    score = 0; reasons = []
    c = closes[:-1]; h = highs[:-1]; l = lows[:-1]
    price = c[-1]
    def ema_f(p,n):
        k=2/(n+1);e=p[0]
        for v in p[1:]: e=v*k+e*(1-k)
        return e
    e20 = ema_f(c, 20)
    # 1. 延迟确认：前一根K方向与趋势一致
    if len(c) >= 2:
        prev_bull = c[-1] > c[-2]
        if (trend=="多" and prev_bull) or (trend=="空" and not prev_bull):
            score += 1; reasons.append("延迟确认✓")
    # 2. 趋势强度
    if ema_strong:
        score += 1; reasons.append("趋势强✓")
    # 3. 位置合理：偏离EMA20 < ATR*0.5
    if atr > 0 and abs(price - e20) < atr * 0.5:
        score += 1; reasons.append("位置好✓")
    # 4. 非追单：最近K振幅 < ATR*1.2
    if len(h) >= 1 and atr > 0 and (h[-1] - l[-1]) < atr * 1.2:
        score += 1; reasons.append("非追单✓")
    # 5. 结构质量：risk <= ATR*1.0
    if atr > 0 and risk <= atr * 1.0:
        score += 1; reasons.append("结构清晰✓")
    return score, reasons


def _position_suggestion(signal_grade, rr_for_grade, risk, atr, a_plus_sc):
    """仓位建议，展示字段，不影响信号生成"""
    if signal_grade == "C":
        return "谨慎观望"
    if signal_grade == "A" and a_plus_sc >= 3 and rr_for_grade >= 1.3 and risk <= atr * 1.0:
        return "标准仓位"
    return "轻仓试探"


def _signal_duration(symbol, interval, trend, signal_grade):
    """内存追踪信号持续K数，返回 (bars, text)
    注意：使用独立的 _dur_tracker，不与 _signal_tracker 混用
    """
    key = (symbol, interval, trend, signal_grade)
    now = int(time.time())
    entry = _dur_tracker.get(key)
    if entry:
        entry["bars"] += 1; entry["last_seen"] = now
    else:
        # 清除同 symbol/interval 的其他方向记录
        for k in list(_dur_tracker.keys()):
            if k[0] == symbol and k[1] == interval and k != key:
                del _dur_tracker[k]
        _dur_tracker[key] = {"bars": 1, "first_seen": now, "last_seen": now}
        entry = _dur_tracker[key]
    bars = entry["bars"]
    bar_mins = {"1m":1,"3m":3,"5m":5,"15m":15,"30m":30,"1h":60,"4h":240,"1d":1440}.get(interval,15)
    mins = bars * bar_mins
    if mins < 60:
        text = f"持续约{mins}分钟"
    else:
        h_, m_ = divmod(mins, 60)
        text = f"持续约{h_}小时{m_}分钟" if m_ else f"持续约{h_}小时"
    return bars, f"第{bars}根K · {text}"


# =========================================================================
# ========== Phase A：策略统计对照系统 ==========
# =========================================================================
_strategy_log = []
_strategy_log_lock = threading.Lock()
MAX_STRATEGY_LOG = 200

def _calc_reverse_signal(trend, entry, sl, tp1, tp2, tp3):
    """结构镜像反向信号"""
    if not entry or not sl or not tp1:
        return None
    rev_trend = "空" if trend == "多" else "多"
    rev_entry = entry
    rev_sl    = tp1
    rev_tp1   = sl
    risk_step = abs(entry - sl)
    if rev_trend == "空":
        rev_tp2 = smart_round(rev_tp1 - risk_step)
        rev_tp3 = smart_round(rev_tp1 - risk_step * 2)
    else:
        rev_tp2 = smart_round(rev_tp1 + risk_step)
        rev_tp3 = smart_round(rev_tp1 + risk_step * 2)
    rev_rr = round(abs(rev_tp1 - rev_entry) / abs(rev_sl - rev_entry), 2) if abs(rev_sl - rev_entry) > 0 else None
    return {
        "trend": rev_trend, "entry": rev_entry,
        "sl": rev_sl, "tp1": rev_tp1, "tp2": rev_tp2, "tp3": rev_tp3,
        "rr": rev_rr, "state": "waiting", "result": None,
        "open_ts": None, "close_ts": None, "hold_seconds": None,
    }

def _strategy_record(symbol, interval, signal_grade, exec_tag,
                     trend, entry, sl, tp1, tp2, tp3, rr):
    """注册一条策略统计记录（主+反向）"""
    if exec_tag not in ("主交易单", "轻仓试单"):
        return
    if not entry or not sl or not tp1:
        return
    now = int(time.time())
    with _strategy_log_lock:
        for rec in _strategy_log:
            if (rec["symbol"] == symbol and rec["interval"] == interval
                    and rec["trend"] == trend
                    and rec["state"] in ("waiting", "open")):
                return
        rev = _calc_reverse_signal(trend, entry, sl, tp1, tp2, tp3)
        record = {
            "symbol": symbol, "interval": interval,
            "signal_grade": signal_grade, "exec_tag": exec_tag,
            "trend": trend, "entry": entry, "sl": sl,
            "tp1": tp1, "tp2": tp2, "tp3": tp3, "rr": rr,
            "created_ts": now, "state": "waiting",
            "result": None, "open_ts": None, "close_ts": None, "hold_seconds": None,
            "reverse": rev,
        }
        _strategy_log.append(record)
        if len(_strategy_log) > MAX_STRATEGY_LOG:
            active = [r for r in _strategy_log if r["state"] in ("waiting","open")]
            closed = sorted([r for r in _strategy_log if r["state"] == "closed"],
                            key=lambda x: x.get("close_ts") or 0)
            _strategy_log[:] = active + closed[-(MAX_STRATEGY_LOG - len(active)):]

def _tick_one(rec, high, low, current_ts):
    """单条信号状态机 tick"""
    state = rec.get("state", "waiting")
    if state == "closed":
        return
    entry = rec.get("entry"); sl = rec.get("sl"); tp1 = rec.get("tp1")
    tp2   = rec.get("tp2");   tp3 = rec.get("tp3"); trend = rec.get("trend")
    if not entry or not sl or not tp1:
        return
    if state == "waiting":
        if low <= entry <= high:
            rec["state"] = "open"; rec["open_ts"] = current_ts; state = "open"
    if state == "open":
        sl_hit  = (trend=="多" and low<=sl)  or (trend=="空" and high>=sl)
        tp1_hit = (trend=="多" and high>=tp1) or (trend=="空" and low<=tp1)
        tp2_hit = tp2 and ((trend=="多" and high>=tp2) or (trend=="空" and low<=tp2))
        tp3_hit = tp3 and ((trend=="多" and high>=tp3) or (trend=="空" and low<=tp3))
        res = None
        if sl_hit:            res = "sl"     # 止损优先
        elif tp3_hit:         res = "tp3"
        elif tp2_hit:         res = "tp2"
        elif tp1_hit:         res = "tp1"
        if res:
            rec["state"] = "closed"; rec["result"] = res; rec["close_ts"] = current_ts
            rec["hold_seconds"] = current_ts - (rec.get("open_ts") or rec.get("created_ts", current_ts))

def _strategy_tick(symbol, interval, high, low, current_ts):
    """每次 analyze() 后推进信号状态机"""
    with _strategy_log_lock:
        for rec in _strategy_log:
            if rec["symbol"] != symbol or rec["interval"] != interval:
                continue
            _tick_one(rec, high, low, current_ts)
            if rec.get("reverse"):
                _tick_one(rec["reverse"], high, low, current_ts)

def _strategy_stats_slice(records):
    """对一批记录计算统计指标"""
    total = len(records)
    if total == 0:
        return {"total": 0}
    settled  = [r for r in records if r.get("state") == "closed"]
    n_set = len(settled)
    tp1_h = sum(1 for r in settled if r.get("result") == "tp1")
    tp2_h = sum(1 for r in settled if r.get("result") == "tp2")
    tp3_h = sum(1 for r in settled if r.get("result") == "tp3")
    sl_h  = sum(1 for r in settled if r.get("result") == "sl")
    win   = tp1_h + tp2_h + tp3_h
    rrs   = [r["rr"] for r in records if r.get("rr") is not None]
    holds = [r["hold_seconds"] for r in settled if r.get("hold_seconds")]
    wr    = round(win / n_set * 100, 1) if n_set > 0 else None
    ar    = round(sum(rrs)/len(rrs), 2) if rrs else None
    ev    = round((wr/100)*ar - (1-wr/100), 3) if (wr is not None and ar is not None) else None
    return {
        "total": total, "settled": n_set,
        "waiting": sum(1 for r in records if r.get("state")=="waiting"),
        "open":    sum(1 for r in records if r.get("state")=="open"),
        "win_rate": wr, "tp1_rate": round(tp1_h/n_set*100,1) if n_set else None,
        "tp2_rate": round(tp2_h/n_set*100,1) if n_set else None,
        "tp3_rate": round(tp3_h/n_set*100,1) if n_set else None,
        "sl_rate":  round(sl_h/n_set*100,1)  if n_set else None,
        "avg_rr": ar, "avg_hold_s": round(sum(holds)/len(holds)) if holds else None,
        "ev": ev,
        "long_count":  sum(1 for r in records if r.get("trend")=="多"),
        "short_count": sum(1 for r in records if r.get("trend")=="空"),
    }

def get_strategy_stats():
    """返回多维策略统计"""
    with _strategy_log_lock:
        log = list(_strategy_log)
    if not log:
        return {"total": 0, "note": "暂无统计数据（可交易信号出现后自动累积）"}
    overall       = _strategy_stats_slice(log)
    by_interval   = {iv: _strategy_stats_slice([r for r in log if r["interval"]==iv])
                     for iv in ("15m","1h","4h") if any(r["interval"]==iv for r in log)}
    by_exec_tag   = {tg: _strategy_stats_slice([r for r in log if r["exec_tag"]==tg])
                     for tg in ("主交易单","轻仓试单") if any(r["exec_tag"]==tg for r in log)}
    by_direction  = {"多": _strategy_stats_slice([r for r in log if r["trend"]=="多"]),
                     "空": _strategy_stats_slice([r for r in log if r["trend"]=="空"])}
    rev_recs      = [r["reverse"] for r in log if r.get("reverse")]
    rev_overall   = _strategy_stats_slice(rev_recs)
    rev_by_interval = {iv: _strategy_stats_slice([r["reverse"] for r in log
                                                   if r["interval"]==iv and r.get("reverse")])
                        for iv in ("15m","1h","4h") if any(r["interval"]==iv for r in log)}
    me = overall.get("ev"); re = rev_overall.get("ev")
    comparison = {
        "main_ev": me, "rev_ev": re,
        "better": ("主策略" if (me or 0)>=(re or 0) else "反向策略") if (me is not None or re is not None) else None,
        "note": (f"{'主策略' if (me or 0)>=(re or 0) else '反向策略'}期望值更高（差距{round(abs((me or 0)-(re or 0)),3)}）"
                 if (me is not None and re is not None) else "结算数据不足"),
    }
    return {
        "total": len(log),
        "note": f"共{len(log)}条信号，{overall.get('settled',0)}条已结算",
        "overall": overall, "by_interval": by_interval,
        "by_exec_tag": by_exec_tag, "by_direction": by_direction,
        "rev_overall": rev_overall, "rev_by_interval": rev_by_interval,
        "comparison": comparison,
        "records": sorted(log, key=lambda x: x.get("created_ts",0), reverse=True)[:100],
    }


# ========== 旧模拟统计（保留兼容） ==========
_sim_log = []   # 最近50条 A/B 信号快照

def _sim_update(symbol, interval, signal_grade, trend, entry, sl, tp1, tp2, rr, closes_recent):
    """追加/结算模拟信号记录"""
    global _sim_log
    if signal_grade not in ("A","B"):
        return
    now = int(time.time())
    # 结算旧未结算记录
    for rec in _sim_log:
        if rec["symbol"]==symbol and rec["result"] is None and rec["entry"] and rec["sl"] and rec["tp1"]:
            e=float(rec["entry"]); s=float(rec["sl"]); t1=float(rec["tp1"])
            for cv in closes_recent:
                if rec["trend"]=="多":
                    if cv>=t1: rec["result"]="tp1"; break
                    if cv<=s:  rec["result"]="sl";  break
                else:
                    if cv<=t1: rec["result"]="tp1"; break
                    if cv>=s:  rec["result"]="sl";  break
    # 同币同方向同档位不重复追加
    last = next((r for r in reversed(_sim_log) if r["symbol"]==symbol and r["interval"]==interval), None)
    if last and last["trend"]==trend and last["signal_grade"]==signal_grade:
        return
    _sim_log.append({"symbol":symbol,"interval":interval,"signal_grade":signal_grade,
                     "trend":trend,"entry":entry,"sl":sl,"tp1":tp1,"tp2":tp2,
                     "rr":rr,"ts":now,"result":None})
    if len(_sim_log) > 50:
        _sim_log = _sim_log[-50:]


def get_sim_stats():
    """返回模拟统计概览"""
    total = len(_sim_log)
    if total == 0:
        return {"total":0,"win_rate":None,"tp1_rate":None,"sl_rate":None,
                "avg_rr":None,"long_count":0,"short_count":0,"pending":0,
                "note":"暂无信号记录（服务启动后自动积累）"}
    settled = [r for r in _sim_log if r["result"] is not None]
    pending = total - len(settled)
    tp1_hits = sum(1 for r in settled if r["result"]=="tp1")
    sl_hits  = sum(1 for r in settled if r["result"]=="sl")
    rrs = [float(r["rr"]) for r in _sim_log if r.get("rr") is not None]
    return {
        "total":       total,
        "pending":     pending,
        "win_rate":    round(tp1_hits/len(settled)*100,1) if settled else None,
        "tp1_rate":    round(tp1_hits/len(settled)*100,1) if settled else None,
        "sl_rate":     round(sl_hits /len(settled)*100,1) if settled else None,
        "avg_rr":      round(sum(rrs)/len(rrs),2) if rrs else None,
        "long_count":  sum(1 for r in _sim_log if r["trend"]=="多"),
        "short_count": sum(1 for r in _sim_log if r["trend"]=="空"),
        "note":        f"已记录{total}条，{len(settled)}条已结算，{pending}条待结算",
    }


# =========================================================================
# ========== Phase B：模拟自动交易系统 ==========
# =========================================================================
# 全内存，重启归零；字段均基础类型便于 JSON 持久化升级
# =========================================================================

SIM_DEFAULTS = {
    "enabled":          False,
    "mode":             "main",       # main / reverse / both
    "initial_equity":   10000.0,      # USDT
    "margin_per_trade": 100.0,        # 每单保证金
    "leverage":         10,
    "max_positions":    5,
    "allow_same_symbol": False,
    "allow_add_same_dir": False,
    "tp_mode":          "partial",    # partial（分批止盈） / tp1_only
    "sl_mode":          "strict",     # strict / breakeven（保本上移）
    "fee_rate":         0.0005,       # 0.05%
    "slippage_rate":    0.0003,       # 0.03%
    "breakeven_r":      0.8,          # 触达 0.8R 后移本
}

_sim_account = {
    "config":            dict(SIM_DEFAULTS),
    "total_equity":      SIM_DEFAULTS["initial_equity"],
    "available_balance": SIM_DEFAULTS["initial_equity"],
    "used_margin":       0.0,
    "unrealized_pnl":    0.0,
    "realized_pnl":      0.0,
    "max_drawdown":      0.0,
    "peak_equity":       SIM_DEFAULTS["initial_equity"],
    "liquidation_count": 0,
    "open_positions":    [],     # 当前持仓列表
    "closed_positions":  [],     # 历史平仓列表（最近200条）
    "today_pnl":         0.0,
    "today_date":        "",     # YYYY-MM-DD
}
_sim_account_lock = threading.Lock()


def _sim_apply_config(cfg: dict):
    """更新模拟交易配置并重置账户（如果 reset=True）"""
    with _sim_account_lock:
        reset = cfg.pop("reset", False)
        for k, v in cfg.items():
            if k in _sim_account["config"]:
                # fee_rate 前端传的是百分比形式（如0.10表示0.1%），需转为小数
                if k == "fee_rate" and v is not None:
                    v = float(v) / 100.0 if float(v) > 0.1 else float(v)
                _sim_account["config"][k] = v
        if reset:
            init_eq = _sim_account["config"]["initial_equity"]
            _sim_account.update({
                "total_equity": init_eq, "available_balance": init_eq,
                "used_margin": 0.0, "unrealized_pnl": 0.0,
                "realized_pnl": 0.0, "max_drawdown": 0.0,
                "peak_equity": init_eq, "liquidation_count": 0,
                "open_positions": [], "closed_positions": [],
                "today_pnl": 0.0, "today_date": "",
            })


def _sim_liquidation_price(trend, entry, leverage):
    """近似爆仓价"""
    if leverage <= 0:
        return None
    if trend == "多":
        return smart_round(entry * (1 - 1 / leverage))
    else:
        return smart_round(entry * (1 + 1 / leverage))


def _sim_open_position(symbol, interval, trend, entry_type,
                       entry_price, stop_loss, tp1, tp2, tp3,
                       signal_grade, exec_tag, market_price, strategy="main"):
    """尝试开仓：检查资金/持仓限制，成功则扣保证金并写入 open_positions"""
    with _sim_account_lock:
        cfg = _sim_account["config"]
        if not cfg["enabled"]:
            return False, "模拟系统未启用"

        # 策略模式过滤
        if cfg["mode"] == "main" and strategy != "main":
            return False, "当前仅主策略模式"
        if cfg["mode"] == "reverse" and strategy != "reverse":
            return False, "当前仅反向策略模式"

        avail = _sim_account["available_balance"]
        margin = cfg["margin_per_trade"]
        lev    = cfg["leverage"]
        fee_r  = cfg["fee_rate"]
        slip_r = cfg["slippage_rate"]

        if avail < margin:
            return False, "可用余额不足"
        if len(_sim_account["open_positions"]) >= cfg["max_positions"]:
            return False, "达到最大持仓数"

        # 同币种检查：反向策略(strategy=reverse)与主策略(main)共存同一symbol是允许的
        same_sym = [p for p in _sim_account["open_positions"] if p["symbol"] == symbol]
        same_strategy_sym = [p for p in same_sym if p["strategy"] == strategy]
        if same_strategy_sym and not cfg["allow_same_symbol"]:
            return False, "禁止同策略同币种重复开仓"
        # 同策略同方向加仓检查
        same_dir = [p for p in same_strategy_sym if p["trend"] == trend]
        if same_dir and not cfg["allow_add_same_dir"]:
            return False, "禁止同方向加仓"

        # 成交价 = market_price ± slippage
        slip = market_price * slip_r
        fill_price = smart_round(market_price + slip if trend == "空" else market_price - slip)

        # 名义仓位 & 数量
        notional  = margin * lev
        qty       = notional / fill_price

        # 手续费（开仓）
        open_fee = notional * fee_r

        # 扣保证金+手续费
        _sim_account["available_balance"] -= (margin + open_fee)
        _sim_account["used_margin"]       += margin

        liq_price = _sim_liquidation_price(trend, fill_price, lev)
        now = int(time.time())

        pos = {
            "id":            now,
            "symbol":        symbol,
            "interval":      interval,
            "strategy":      strategy,        # main / reverse
            "signal_grade":  signal_grade,
            "exec_tag":      exec_tag,
            "trend":         trend,
            "entry_price":   fill_price,
            "stop_loss":     stop_loss,
            "sl_moved":      False,           # 是否已移本
            "tp1":           tp1,
            "tp2":           tp2,
            "tp3":           tp3,
            "tp1_closed":    False,
            "tp2_closed":    False,
            "leverage":      lev,
            "margin":        margin,
            "notional":      notional,
            "qty":           round(qty, 8),
            "qty_remaining": round(qty, 8),
            "open_fee":      round(open_fee, 4),
            "slippage":      round(slip, 6),
            "open_ts":       now,
            "close_ts":      None,
            "realized_pnl":  0.0,
            "liquidated":    False,
            "liq_price":     liq_price,
        }
        _sim_account["open_positions"].append(pos)
        return True, pos


def _sim_close_partial(pos, qty_to_close, close_price, reason, fee_rate, slippage_rate):
    """平仓部分或全部，返回 realized_pnl"""
    slip = close_price * slippage_rate
    fill = smart_round(close_price - slip if pos["trend"] == "多" else close_price + slip)
    pnl_per_unit = (fill - pos["entry_price"]) if pos["trend"] == "多" else (pos["entry_price"] - fill)
    pnl  = pnl_per_unit * qty_to_close
    fee  = fill * qty_to_close * fee_rate
    net  = round(pnl - fee, 4)
    pos["qty_remaining"] = round(pos["qty_remaining"] - qty_to_close, 8)
    pos["realized_pnl"]  = round(pos["realized_pnl"] + net, 4)
    return net, fill


def _sim_tick_positions(symbol, interval, high, low, current_price, current_ts):
    """每次 analyze() 后推进所有相关持仓的 TP/SL/爆仓逻辑"""
    with _sim_account_lock:
        cfg  = _sim_account["config"]
        fee  = cfg["fee_rate"]
        slip = cfg["slippage_rate"]
        be_r = cfg["breakeven_r"]
        to_close = []   # (pos_id, 原因)

        for pos in list(_sim_account["open_positions"]):
            if pos["symbol"] != symbol or pos["interval"] != interval:
                continue
            trend = pos["trend"]
            ep    = pos["entry_price"]
            sl    = pos["stop_loss"]

            # 爆仓检查（优先）
            liq = pos.get("liq_price")
            if liq:
                liqd = (trend == "多" and low <= liq) or (trend == "空" and high >= liq)
                if liqd:
                    pos["liquidated"] = True
                    pnl, _ = _sim_close_partial(pos, pos["qty_remaining"], liq, "liquidation", fee, slip)
                    to_close.append((pos, "liquidation", pnl))
                    continue

            # 止损检查（优先于止盈）
            sl_hit = (trend == "多" and low <= sl) or (trend == "空" and high >= sl)
            if sl_hit:
                pnl, _ = _sim_close_partial(pos, pos["qty_remaining"], sl, "sl", fee, slip)
                to_close.append((pos, "sl", pnl))
                continue

            # 保本上移检查（0.8R）
            risk = abs(ep - pos["stop_loss"])
            if cfg["sl_mode"] == "breakeven" and not pos["sl_moved"] and risk > 0:
                be_price = smart_round(ep + risk * be_r if trend == "多" else ep - risk * be_r)
                be_touched = (trend == "多" and high >= be_price) or (trend == "空" and low <= be_price)
                if be_touched:
                    pos["stop_loss"] = ep   # 移本
                    pos["sl_moved"]  = True

            # TP1（平50%）
            tp1 = pos.get("tp1")
            if tp1 and not pos["tp1_closed"]:
                tp1_hit = (trend == "多" and high >= tp1) or (trend == "空" and low <= tp1)
                if tp1_hit:
                    if cfg["tp_mode"] == "tp1_only":
                        pnl, _ = _sim_close_partial(pos, pos["qty_remaining"], tp1, "tp1", fee, slip)
                        to_close.append((pos, "tp1", pnl))
                        continue
                    else:
                        qty50 = round(pos["qty_remaining"] * 0.5, 8)
                        pnl, _ = _sim_close_partial(pos, qty50, tp1, "tp1", fee, slip)
                        pos["tp1_closed"] = True
                        _sim_account["realized_pnl"]      += pnl
                        _sim_account["total_equity"]      += pnl
                        _sim_account["available_balance"] += pnl
                        _update_today_pnl(pnl)

            # TP2（平30%）
            tp2 = pos.get("tp2")
            if tp2 and pos["tp1_closed"] and not pos["tp2_closed"]:
                tp2_hit = (trend == "多" and high >= tp2) or (trend == "空" and low <= tp2)
                if tp2_hit:
                    qty30 = round(pos["qty_remaining"] * (0.3 / 0.5), 8)  # 剩余的60%
                    pnl, _ = _sim_close_partial(pos, qty30, tp2, "tp2", fee, slip)
                    pos["tp2_closed"] = True
                    _sim_account["realized_pnl"]      += pnl
                    _sim_account["total_equity"]      += pnl
                    _sim_account["available_balance"] += pnl
                    _update_today_pnl(pnl)

            # TP3（平剩余全部）
            tp3 = pos.get("tp3")
            if tp3 and pos["tp1_closed"] and pos["tp2_closed"]:
                tp3_hit = (trend == "多" and high >= tp3) or (trend == "空" and low <= tp3)
                if tp3_hit:
                    pnl, _ = _sim_close_partial(pos, pos["qty_remaining"], tp3, "tp3", fee, slip)
                    to_close.append((pos, "tp3", pnl))
                    continue

        # 处理需要完全平仓的仓位
        for pos, reason, pnl in to_close:
            _sim_account["open_positions"].remove(pos)
            pos["close_ts"]  = current_ts
            pos["close_reason"] = reason
            _sim_account["realized_pnl"]      += pnl
            _sim_account["total_equity"]      += pnl
            _sim_account["available_balance"] += (pos["margin"] + pnl)
            _sim_account["used_margin"]       -= pos["margin"]
            if reason == "liquidation":
                _sim_account["liquidation_count"] += 1
                _sim_account["available_balance"] -= pos["margin"]  # 爆仓损失全部保证金
                _sim_account["total_equity"]      -= pos["margin"]
            _update_today_pnl(pnl)
            # 更新峰值和最大回撤
            eq = _sim_account["total_equity"]
            if eq > _sim_account["peak_equity"]:
                _sim_account["peak_equity"] = eq
            dd = (_sim_account["peak_equity"] - eq) / _sim_account["peak_equity"] * 100 if _sim_account["peak_equity"] > 0 else 0
            if dd > _sim_account["max_drawdown"]:
                _sim_account["max_drawdown"] = round(dd, 2)
            # 归档
            _sim_account["closed_positions"].append(pos)
            if len(_sim_account["closed_positions"]) > 200:
                _sim_account["closed_positions"] = _sim_account["closed_positions"][-200:]
            # 权益归零则停止
            if _sim_account["total_equity"] <= 0:
                _sim_account["config"]["enabled"] = False
                _sim_account["total_equity"] = 0

        # 计算浮动盈亏
        upnl = 0.0
        for pos in _sim_account["open_positions"]:
            pnl_per = (current_price - pos["entry_price"]) if pos["trend"] == "多" else (pos["entry_price"] - current_price)
            upnl += pnl_per * pos["qty_remaining"]
        _sim_account["unrealized_pnl"] = round(upnl, 4)


def _update_today_pnl(pnl):
    """累计今日盈亏"""
    today = time.strftime("%Y-%m-%d", time.gmtime())
    if _sim_account["today_date"] != today:
        _sim_account["today_date"] = today
        _sim_account["today_pnl"]  = 0.0
    _sim_account["today_pnl"] = round(_sim_account["today_pnl"] + pnl, 4)


def get_sim_account():
    """返回当前虚拟账户快照（供 API），实时用 markPrice 刷新浮盈"""
    with _sim_account_lock:
        cfg  = _sim_account["config"]
        ops  = list(_sim_account["open_positions"])
        cls  = list(_sim_account["closed_positions"])
        settled = [p for p in cls if not p.get("liquidated")]
        wins    = [p for p in settled if p.get("realized_pnl", 0) > 0]
        win_rate = round(len(wins) / len(settled) * 100, 1) if settled else None
        total_fee = sum(p.get("open_fee",0) for p in cls+ops)

        # 实时拉 markPrice 重算每仓浮盈
        total_upnl = 0.0
        for pos in ops:
            try:
                mp = get_market_price(pos["symbol"])
                if mp and mp > 0:
                    pnl_per = (mp - pos["entry_price"]) if pos["trend"] == "多" else (pos["entry_price"] - mp)
                    upnl_pos = round(pnl_per * pos["qty_remaining"], 4)
                    upnl_pct = round(pnl_per / pos["entry_price"] * 100 * pos["leverage"], 2) if pos["entry_price"] > 0 else 0
                    pos["_cur_price"]   = mp
                    pos["_upnl"]        = upnl_pos
                    pos["_upnl_pct"]    = upnl_pct
                    total_upnl += upnl_pos
                else:
                    pos["_cur_price"]   = pos.get("_cur_price", pos["entry_price"])
                    pos["_upnl"]        = pos.get("_upnl", 0.0)
                    pos["_upnl_pct"]    = pos.get("_upnl_pct", 0.0)
                    total_upnl += pos.get("_upnl", 0.0)
            except Exception:
                pos["_upnl"] = 0.0
                pos["_upnl_pct"] = 0.0
        _sim_account["unrealized_pnl"] = round(total_upnl, 4)

        return {
            "enabled":           cfg["enabled"],
            "config":            dict(cfg),
            "total_equity":      round(_sim_account["total_equity"] + total_upnl, 2),
            "available_balance": round(_sim_account["available_balance"], 2),
            "used_margin":       round(_sim_account["used_margin"], 2),
            "unrealized_pnl":    round(total_upnl, 4),
            "realized_pnl":      round(_sim_account["realized_pnl"], 4),
            "today_pnl":         round(_sim_account["today_pnl"] + total_upnl, 4),
            "max_drawdown":      _sim_account["max_drawdown"],
            "peak_equity":       round(_sim_account["peak_equity"], 2),
            "liquidation_count": _sim_account["liquidation_count"],
            "open_count":        len(ops),
            "closed_count":      len(cls),
            "win_rate":          win_rate,
            "total_fee":         round(total_fee, 4),
            "open_positions":    ops,
            "closed_positions":  cls[-50:],
        }


def _score_signal(trend, higher_trend, ema_strong, structure_ok, vol_ok, interval):
    """统一信号评分逻辑（analyze和_layer2_full共用）
    返回：signal_grade, direction_label, signal_score, higher_ok
    """
    higher_ok = (trend == higher_trend and trend != "中性")
    opposite  = (trend != "中性" and higher_trend != "中性" and trend != higher_trend)

    if opposite:
        return "C", "逆势观察", 0, False

    if trend == "中性":
        return "C", "观察", 0, False

    ema_ok       = ema_strong
    signal_score = sum([higher_ok, ema_ok, structure_ok, vol_ok])

    direction_label = "做多" if trend == "多" else "做空"
    # 暂返回score，分档在调用方做（需要space/RR）
    return None, direction_label, signal_score, higher_ok


def _calc_tp_sl(trend, entry, support, resistance, atr, interval, signal_grade,
                highs5=None, lows5=None):
    """统一止损止盈计算（两套模型：scalp=5m旧模型；trade=15m以上新模型）
    返回 stop_loss, tp1, tp2, tp3, risk, space, rr
    """
    atr_buf   = ATR_BUF.get(interval, 0.3)
    is_scalp  = (interval == "5m")
    min_risk_atr = SCALP_MIN_RISK_ATR if is_scalp else TRADE_MIN_RISK_ATR.get(interval, 1.0)

    if trend == "多":
        sl_anchor = min(lows5) if lows5 else support
        stop_loss = smart_round(sl_anchor - atr * atr_buf)
        risk      = max(abs(entry - stop_loss), atr * min_risk_atr)
        space     = max(resistance - entry, atr * 1.0) if resistance > entry else atr * 1.0
    elif trend == "空":
        sl_anchor = max(highs5) if highs5 else resistance
        stop_loss = smart_round(sl_anchor + atr * atr_buf)
        risk      = max(abs(stop_loss - entry), atr * min_risk_atr)
        space     = max(entry - support, atr * 1.0) if support < entry else atr * 1.0
    else:
        return None, None, None, None, atr * 0.3, atr * 1.0, 0.0

    if signal_grade not in ("A", "B"):
        return None, None, None, None, risk, space, 0.0

    # 两套 TP 模型
    if is_scalp:
        tp1_dist = max(risk * SCALP_TP1_RISK_MULT, atr * SCALP_TP1_ATR_FLOOR)
        tp2_dist = max(risk * SCALP_TP2_RISK_MULT, atr * SCALP_TP2_ATR_FLOOR)
        tp3_dist = max(risk * SCALP_TP3_RISK_MULT, atr * SCALP_TP3_ATR_FLOOR)
    else:
        tp1_dist = max(risk * TRADE_TP1_RISK_MULT, atr * TRADE_TP1_ATR_FLOOR)
        tp2_dist = max(risk * TRADE_TP2_RISK_MULT, atr * TRADE_TP2_ATR_FLOOR)
        tp3_dist = max(risk * TRADE_TP3_RISK_MULT, atr * TRADE_TP3_ATR_FLOOR)

    if trend == "多":
        tp1 = smart_round(entry + tp1_dist)
        tp2 = smart_round(entry + tp2_dist)
        tp3 = smart_round(entry + tp3_dist)
    else:
        tp1 = smart_round(entry - tp1_dist)
        tp2 = smart_round(entry - tp2_dist)
        tp3 = smart_round(entry - tp3_dist)

    rr_val = round(tp1_dist / risk, 2) if risk > 0 else 0.0
    return stop_loss, tp1, tp2, tp3, risk, space, rr_val

def _layer1_filter(top_n=50):
    """第一层：1次请求拿全市场数据，筛出候选池（无K线请求）
    top_n 控制主通道数量，bonus通道固定10个（高波动补充）
    """
    tickers = binance_get("/fapi/v1/ticker/24hr", timeout=8)
    candidates = []
    for t in tickers:
        sym = t["symbol"]
        if not sym.endswith("USDT"):
            continue
        try:
            qvol = float(t["quoteVolume"])
            price = float(t["lastPrice"])
            change_pct = float(t["priceChangePercent"])
            high = float(t["highPrice"])
            low = float(t["lowPrice"])
            if price <= 0 or low <= 0:
                continue
            volatility = (high - low) / low * 100
            candidates.append({
                "symbol": sym,
                "price": price,
                "qvol": qvol,
                "change_pct": change_pct,
                "volatility": volatility,
            })
        except Exception:
            continue

    if not candidates:
        return []

    by_vol = sorted(candidates, key=lambda x: -x["qvol"])
    # 主通道：按top_n取（真正响应参数）
    main_pool = by_vol[:top_n]
    main_syms = {c["symbol"] for c in main_pool}

    # 补漏通道：高波动但不在主通道，固定限10个（大幅缩减）
    bonus = [c for c in by_vol[top_n:] if c["volatility"] > 8.0][:10]

    return main_pool + bonus


def _layer2_full(symbol, interval, ticker_data=None):
    """第二层：与详情页同一套算法，只拉K线，量能用成交量"""
    try:
        kl = binance_get("/fapi/v1/klines", {"symbol": symbol, "interval": interval, "limit": "65"}, timeout=4)
        closes  = [float(k[4]) for k in kl]
        highs   = [float(k[2]) for k in kl]
        lows    = [float(k[3]) for k in kl]
        volumes = [float(k[5]) for k in kl]

        higher_interval = HIGHER_INTERVAL.get(interval, "1d")
        hkl = binance_get("/fapi/v1/klines", {"symbol": symbol, "interval": higher_interval, "limit": "65"}, timeout=4)
        h_closes = [float(k[4]) for k in hkl]
        h_highs  = [float(k[2]) for k in hkl]
        h_lows   = [float(k[3]) for k in hkl]

        current = analyze_trend(closes, highs, lows, interval)
        higher  = analyze_trend(h_closes, h_highs, h_lows, higher_interval)
        if not current or not higher:
            return None

        trend        = current["trend"]
        higher_trend = higher["trend"]
        atr          = current["atr"]

        # 量能（已收盘成交量）
        vols     = volumes[:-1]
        vol_ma10 = sum(vols[-10:]) / min(len(vols), 10)
        vol_ok   = sum(1 for v in vols[-3:] if v > vol_ma10 * 1.1) >= 2

        _, direction_label, signal_score, higher_ok = _score_signal(
            trend, higher_trend, current["ema_strong"], current["structure_ok"], vol_ok, interval
        )

        support    = current["support"]
        resistance = current["resistance"]
        kline_close = current["current_price"]

        # 统一市场价（与 analyze() 一致，markPrice 作为执行基准）
        market_p = get_market_price(symbol)
        entry = market_p if market_p else kline_close
        entry = float(entry)

        highs5     = highs[:-1][-5:]  # 近5根已收盘高点
        lows5      = lows[:-1][-5:]   # 近5根已收盘低点
        atr_buf    = ATR_BUF.get(interval, 0.3)

        # 近端止损计算
        if trend == "多":
            sl_anchor = min(lows5)
            risk = max(abs(entry - (sl_anchor - atr * atr_buf)), atr * 0.3)
            space = max(resistance - entry, atr * 1.0) if resistance > entry else atr * 1.0
        elif trend == "空":
            sl_anchor = max(highs5)
            risk = max(abs((sl_anchor + atr * atr_buf) - entry), atr * 0.3)
            space = max(entry - support, atr * 1.0) if support < entry else atr * 1.0
        else:
            risk = atr * 0.3
            space = atr * 1.0

        tp1_dist_g = max(risk * 1.2, atr * 0.8)
        tp2_dist_g = max(risk * 2.0, atr * 1.6)
        rr_for_grade = round(tp1_dist_g / risk, 2) if risk > 0 else 0.0
        cost       = entry * 0.0008 * 2 + atr * 0.05
        cost_ok    = (tp1_dist_g > cost * 2) and (tp2_dist_g > cost * 3)

        if direction_label in ("逆势观察", "观察") or trend == "中性":
            signal_grade = "C"
        elif signal_score >= 3 and space >= atr * 1.0 and rr_for_grade >= 1.4 and cost_ok:
            signal_grade = "A"
        elif signal_score >= 2 and higher_ok and space >= atr * 0.7 and rr_for_grade >= 1.1 and cost_ok:
            signal_grade = "B"
        else:
            signal_grade = "C"

        result = {
            "symbol":         symbol,
            "close":          smart_round(kline_close),   # K线信号计算价
            "market_price":   smart_round(entry),         # 统一市场价
            "trend":          trend,
            "signal_grade":   signal_grade,
            "direction_label": direction_label,
            "score":          signal_score,
            "rsi":            round(current["rsi"], 1),
            "higher_trend":   higher_trend,
            "space":          smart_round(space),
            "rr":             rr_for_grade if signal_grade in ("A","B") else None,
            "atr":            smart_round(atr),
        }
        # v10：为扫描层追加 A+/仓位/持续时间/执行层
        if signal_grade in ("A", "B"):
            ap_sc, ap_rs = _a_plus_score(trend, closes, highs, lows, atr,
                                         current["ema_strong"], risk, signal_grade)
            is_ap = (signal_grade=="A" and ap_sc>=3) or (signal_grade=="B" and ap_sc>=4 and rr_for_grade>=1.2)
            dur_b, dur_t = _signal_duration(symbol, interval, trend, signal_grade)
            pos_s = _position_suggestion(signal_grade, rr_for_grade, risk, atr, ap_sc)
            # 执行层（扫描级）
            sl_raw = None
            if trend == "多":
                sl_raw = smart_round(min(lows5) - atr * atr_buf)
            elif trend == "空":
                sl_raw = smart_round(max(highs5) + atr * atr_buf)
            tp1_raw = None
            if sl_raw and signal_grade in ("A","B"):
                risk_ex  = max(abs(entry - sl_raw), TRADE_MIN_RISK_ATR.get(interval, 1.0) * atr if interval != "5m" else SCALP_MIN_RISK_ATR * atr)
                t1m, t1f = (TRADE_TP1_RISK_MULT, TRADE_TP1_ATR_FLOOR) if interval != "5m" else (SCALP_TP1_RISK_MULT, SCALP_TP1_ATR_FLOOR)
                tp1_dist_ex = max(risk_ex * t1m, atr * t1f)
                tp1_raw = smart_round(entry + tp1_dist_ex if trend == "多" else entry - tp1_dist_ex)
            tp1_pct_scan = round(abs(tp1_raw - entry) / entry * 100, 2) if tp1_raw and entry else None
            sl_pct_scan  = round(abs(sl_raw - entry) / entry * 100, 2) if sl_raw and entry else None
            rr_scan      = round(abs(tp1_raw - entry) / abs(sl_raw - entry), 2) if (tp1_raw and sl_raw and abs(sl_raw - entry) > 0) else None
            trade_style_s = TRADE_STYLE.get(interval, "trade")
            invalid_bars = INVALID_BARS.get(interval, 2)
            age_bars     = max(0, dur_b - 1) if dur_b else 0

            # 容忍度判断（扫描层用 entry_zone ± 0.2ATR）
            if trend == "多":
                ez_lo = entry - atr * 0.3; ez_hi = entry
            else:
                ez_lo = entry; ez_hi = entry + atr * 0.3
            near_entry_s = (ez_lo - atr * 0.2 <= entry <= ez_hi + atr * 0.2)  # 扫描层始终near（market_price≈entry）

            # 失效判断：age超限 且 偏离容忍度
            stale = (age_bars > invalid_bars) and not near_entry_s

            # 扫描层 execution_tag（简化版）
            if stale:
                exec_tag = "已失效"
            elif sl_pct_scan and sl_pct_scan > SL_PCT_LIMIT.get(trade_style_s, 5.0):
                exec_tag = "风险过高"
            elif tp1_pct_scan and tp1_pct_scan < 0.6:
                exec_tag = "仅观察"
            elif tp1_pct_scan and tp1_pct_scan >= 1.2 and rr_scan and rr_scan >= 1.1:
                exec_tag = "主交易单"
            else:
                exec_tag = "轻仓试单"

            # 计算 tp2/tp3 原始价格（与 _calc_tp_sl 同一套参数）
            tp2_raw = tp3_raw = None
            if sl_raw and entry:
                _risk_ex = max(abs(entry - sl_raw), TRADE_MIN_RISK_ATR.get(interval, 1.0) * atr if interval != "5m" else SCALP_MIN_RISK_ATR * atr)
                if trend == "多":
                    tp2_raw = smart_round(entry + max(_risk_ex * TRADE_TP2_RISK_MULT, atr * TRADE_TP2_ATR_FLOOR))
                    tp3_raw = smart_round(entry + max(_risk_ex * TRADE_TP3_RISK_MULT, atr * TRADE_TP3_ATR_FLOOR))
                else:
                    tp2_raw = smart_round(entry - max(_risk_ex * TRADE_TP2_RISK_MULT, atr * TRADE_TP2_ATR_FLOOR))
                    tp3_raw = smart_round(entry - max(_risk_ex * TRADE_TP3_RISK_MULT, atr * TRADE_TP3_ATR_FLOOR))

            result.update({
                "a_plus_score":          ap_sc,
                "a_plus_reasons":        ap_rs,
                "is_aplus":              is_ap,
                "position_suggestion":   pos_s,
                "signal_duration_bars":  dur_b,
                "signal_duration_text":  dur_t,
                "tp1_pct":               tp1_pct_scan,
                "sl_pct":                sl_pct_scan,
                "rr":                    rr_scan if rr_scan else rr_for_grade,
                "trade_style":           trade_style_s,
                "signal_age_bars":       age_bars,
                "stale_signal":          stale,
                "execution_tag":         exec_tag,
                # 供模拟开仓直接使用，不需要反推
                "_sl":                   sl_raw,
                "_tp1":                  tp1_raw,
                "_tp2":                  tp2_raw,
                "_tp3":                  tp3_raw,
            })
        else:
            result.update({
                "a_plus_score": 0, "a_plus_reasons": [],
                "is_aplus": False,
                "position_suggestion": "谨慎观望",
                "signal_duration_bars": None, "signal_duration_text": None,
                "tp1_pct": None, "sl_pct": None, "trade_style": TRADE_STYLE.get(interval,"intraday"),
                "signal_age_bars": 0, "stale_signal": False,
            })
        if ticker_data:
            result["change_pct"] = round(ticker_data.get("change_pct", 0), 2)
            result["qvol"]       = ticker_data.get("qvol", 0)
        return result
    except Exception:
        return None


def get_overview(interval="15m", top_n=50):
    """扫描：首页A/B进主区，C进观察区"""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    try:
        candidates = _layer1_filter(top_n)
    except Exception:
        candidates = []

    if not candidates:
        return {
            "interval": interval, "total_scanned": 0,
            "longs": [], "shorts": [], "longs_watch": [], "shorts_watch": [],
            "timestamp": int(time.time())
        }

    ticker_map = {c["symbol"]: c for c in candidates}
    results = []
    with ThreadPoolExecutor(max_workers=20) as ex:
        futures = {
            ex.submit(_layer2_full, sym, interval, ticker_map.get(sym)): sym
            for sym in ticker_map
        }
        for f in as_completed(futures, timeout=45):
            try:
                r = f.result()
                if r:
                    results.append(r)
            except Exception:
                pass

    grade_order = {"A": 3, "B": 2, "C": 1}

    def sort_key(x):
        return (-grade_order.get(x["signal_grade"], 0), -(x.get("space") or 0), -(x.get("rr") or 0))

    # 主区：A/B且未失效（stale_signal=False）
    longs        = sorted([r for r in results
                           if r["trend"] == "多"  and r["signal_grade"] in ("A","B") and not r.get("stale_signal")],
                          key=sort_key)
    shorts       = sorted([r for r in results
                           if r["trend"] == "空"  and r["signal_grade"] in ("A","B") and not r.get("stale_signal")],
                          key=sort_key)
    # 已失效归档区：原A/B但已失效
    longs_stale  = sorted([r for r in results
                           if r["trend"] == "多"  and r["signal_grade"] in ("A","B") and r.get("stale_signal")],
                          key=sort_key)
    shorts_stale = sorted([r for r in results
                           if r["trend"] == "空"  and r["signal_grade"] in ("A","B") and r.get("stale_signal")],
                          key=sort_key)
    # C档观察区
    longs_watch  = sorted([r for r in results if r["trend"] == "多"  and r["signal_grade"] == "C"], key=sort_key)
    shorts_watch = sorted([r for r in results if r["trend"] == "空"  and r["signal_grade"] == "C"], key=sort_key)

    # A+ 优选列表
    aplus_list = sorted(
        [r for r in results if r.get("is_aplus") and not r.get("stale_signal")],
        key=lambda x: (-x.get("a_plus_score", 0), -(x.get("rr") or 0))
    )

    # ===== Phase B：overview 扫描层直接触发模拟开仓 =====
    # 不需要用户点击详情页，扫到 A/B 主交易单/轻仓试单就自动开
    if _sim_account["config"].get("enabled"):
        tradeable = [r for r in results
                     if r["signal_grade"] in ("A","B")
                     and not r.get("stale_signal")
                     and r.get("execution_tag") in ("主交易单","轻仓试单")]
        for r in tradeable:
            sym_r    = r["symbol"]
            trend_r  = r["trend"]
            entry_r  = r.get("market_price") or r.get("close")
            # 直接使用 _layer2_full 算好的 sl/tp 价格，100% 与首页信号卡一致
            sl_r  = r.get("_sl")
            tp1_r = r.get("_tp1")
            tp2_r = r.get("_tp2")
            tp3_r = r.get("_tp3")
            # 如果字段缺失（旧缓存），fallback 用 pct 反推
            if not sl_r and r.get("sl_pct") and entry_r:
                sl_pct_v = r["sl_pct"] / 100
                sl_r = smart_round(entry_r * (1 - sl_pct_v) if trend_r == "多" else entry_r * (1 + sl_pct_v))
            if not tp1_r and r.get("tp1_pct") and entry_r:
                tp1_pct_v = r["tp1_pct"] / 100
                tp1_r = smart_round(entry_r * (1 + tp1_pct_v) if trend_r == "多" else entry_r * (1 - tp1_pct_v))
            # tp2/tp3 兜底
            atr_r = r.get("atr", 0)
            if tp1_r and sl_r and entry_r and not tp2_r:
                risk_r = abs(entry_r - sl_r)
                if trend_r == "多":
                    tp2_r = smart_round(entry_r + max(risk_r * TRADE_TP2_RISK_MULT, atr_r * TRADE_TP2_ATR_FLOOR))
                    tp3_r = smart_round(entry_r + max(risk_r * TRADE_TP3_RISK_MULT, atr_r * TRADE_TP3_ATR_FLOOR))
                else:
                    tp2_r = smart_round(entry_r - max(risk_r * TRADE_TP2_RISK_MULT, atr_r * TRADE_TP2_ATR_FLOOR))
                    tp3_r = smart_round(entry_r - max(risk_r * TRADE_TP3_RISK_MULT, atr_r * TRADE_TP3_ATR_FLOOR))
            if entry_r and sl_r and tp1_r:
                _sim_open_position(
                    sym_r, interval, trend_r, "market",
                    entry_r, sl_r, tp1_r, tp2_r, tp3_r,
                    r["signal_grade"], r["execution_tag"], entry_r, strategy="main"
                )
                # 反向策略
                if _sim_account["config"].get("mode") in ("reverse","both"):
                    rev = _calc_reverse_signal(trend_r, entry_r, sl_r, tp1_r, tp2_r, tp3_r)
                    if rev:
                        _sim_open_position(
                            sym_r, interval, rev["trend"], "market",
                            rev["entry"], rev["sl"], rev["tp1"], rev["tp2"], rev["tp3"],
                            r["signal_grade"], r["execution_tag"], entry_r, strategy="reverse"
                        )
            # tick 已有仓位（用真实 market_price 推进止盈止损判断）
            mp_r = r.get("market_price", entry_r)
            if mp_r:
                _sim_tick_positions(sym_r, interval,
                                    mp_r * 1.0005,   # 模拟当根K线最高
                                    mp_r * 0.9995,   # 模拟当根K线最低
                                    mp_r,
                                    int(time.time()))
    # ===== end Phase B =====

    return {
        "interval":      interval,
        "total_scanned": len(ticker_map),
        "longs":         longs,
        "shorts":        shorts,
        "longs_stale":   longs_stale,
        "shorts_stale":  shorts_stale,
        "longs_watch":   longs_watch,
        "shorts_watch":  shorts_watch,
        "aplus":         aplus_list,
        "sim_stats":     get_sim_stats(),
        "timestamp":     int(time.time()),
    }


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """多线程HTTP服务器：每个请求独立线程，扫描不阻塞其他请求"""
    daemon_threads = True


class WidgetHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # 静默日志

    def send_json(self, data, status=200):
        # ensure_ascii=True 避免中文字符导致Content-Length计算错误
        body = json.dumps(data, ensure_ascii=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_text(self, text, status=200):
        body = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_html(self, html, status=200):
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        if path == "/health":
            self.send_text("ok")

        elif path == "/download/btc_widget_v10.2.zip":
            zip_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "btc_widget_v10.2.zip")
            if os.path.exists(zip_path):
                with open(zip_path, "rb") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Disposition", 'attachment; filename="btc_widget_v10.2.zip"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            else:
                self.send_text("file not found", 404)

        elif path == "/download/okx_widget_v1.0.zip":
            zip_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "okx_widget_v1.0.zip")
            if os.path.exists(zip_path):
                with open(zip_path, "rb") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Disposition", 'attachment; filename="okx_widget_v1.0.zip"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            else:
                self.send_text("file not found", 404)

        elif path == "/":
            # 返回UI
            # v10_dev：使用开发版 UI
            ui_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "widget_ui_v10_dev.html")
            if os.path.exists(ui_path):
                with open(ui_path, "r", encoding="utf-8") as f:
                    html = f.read()
                self.send_html(html)
            else:
                self.send_text("widget_ui_v10_dev.html not found", 404)

        elif path == "/api/symbols":
            try:
                symbols = get_symbols()
                # 加入中文别名，方便搜索
                cn_entries = []
                for cn, en in CN_NAME_MAP.items():
                    if en:
                        matches = [s for s in symbols if s.startswith(en+'USDT') or s == en+'USDT']
                        for m in matches:
                            cn_entries.append({"symbol": m, "cn": cn})
                # 把含中文的symbol也加进cn_entries
                for s in symbols:
                    if any('一' <= c <= '鿿' for c in s):
                        cn_entries.append({"symbol": s, "cn": s})
                self.send_json({"symbols": symbols, "cn_map": cn_entries})
            except Exception as e:
                self.send_json({"error": str(e)}, 500)

        elif path == "/api/overview":
            interval = params.get("interval", ["15m"])[0]
            top_n = int(params.get("top_n", ["50"])[0])
            try:
                result = get_overview(interval, top_n)
                self.send_json(result)
            except Exception as e:
                import traceback
                self.send_json({"error": str(e), "trace": traceback.format_exc()}, 500)

        elif path == "/api/analyze":
            symbol = params.get("symbol", ["BTCUSDT"])[0].upper()
            interval = params.get("interval", ["15m"])[0]
            try:
                result = analyze(symbol, interval)
                self.send_json(result)
            except Exception as e:
                import traceback
                self.send_json({"error": str(e), "trace": traceback.format_exc()}, 500)

        elif path == "/api/price":
            symbol = params.get("symbol", ["BTCUSDT"])[0].upper()
            try:
                book = binance_get("/fapi/v1/ticker/bookTicker", {"symbol": symbol}, timeout=3)
                mark = binance_get("/fapi/v1/premiumIndex", {"symbol": symbol}, timeout=3)
                self.send_json({
                    "symbol":     symbol,
                    "last_price": smart_round(float(mark.get("markPrice", 0))),
                    "bid":        smart_round(float(book.get("bidPrice", 0))),
                    "ask":        smart_round(float(book.get("askPrice", 0))),
                    "ts":         int(time.time() * 1000),
                })
            except Exception as e:
                self.send_json({"error": str(e)}, 500)

        elif path == "/api/strategy_stats":
            try:
                self.send_json(get_strategy_stats())
            except Exception as e:
                import traceback
                self.send_json({"error": str(e), "trace": traceback.format_exc()}, 500)

        elif path == "/api/sim_account":
            try:
                self.send_json(get_sim_account())
            except Exception as e:
                self.send_json({"error": str(e)}, 500)

        else:
            self.send_text("Not Found", 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        try:
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length) if length > 0 else b"{}"
            data = json.loads(body.decode("utf-8"))
        except Exception:
            data = {}

        if path == "/api/sim_config":
            try:
                _sim_apply_config(data)
                self.send_json({"ok": True, "config": _sim_account["config"]})
            except Exception as e:
                self.send_json({"error": str(e)}, 500)
        else:
            self.send_text("Not Found", 404)


def run_server(port=8765, host="0.0.0.0"):
    server = ThreadedHTTPServer((host, port), WidgetHandler)
    import socket
    local_ip = socket.gethostbyname(socket.gethostname())
    print(f"[BTC Widget] Server running at http://0.0.0.0:{port} (多线程模式)")
    print(f"[BTC Widget] 本机访问: http://127.0.0.1:{port}")
    print(f"[BTC Widget] 局域网访问: http://{local_ip}:{port}")
    server.serve_forever()
    server.serve_forever()


def launch_with_pywebview(port=8765):
    import webview
    window = webview.create_window(
        "BTC Widget",
        f"http://127.0.0.1:{port}",
        width=900,
        height=900,
        resizable=True,
    )
    webview.start()


def launch_with_tkinter_fallback():
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.title("BTC Widget - 缺少依赖")
        root.geometry("400x200")
        label = tk.Label(
            root,
            text="请安装 pywebview 以使用桌面窗口模式：\n\npip install pywebview\n\n或直接浏览器访问：\nhttp://127.0.0.1:8765",
            justify="center",
            pady=20,
        )
        label.pack(expand=True)
        btn = tk.Button(root, text="关闭", command=root.destroy)
        btn.pack(pady=10)
        root.mainloop()
    except Exception:
        print("请安装 pywebview: pip install pywebview")
        print("或直接浏览器访问: http://127.0.0.1:8765")


if __name__ == "__main__":
    PORT = 8765

    # 先启动服务器线程
    t = threading.Thread(target=run_server, args=(PORT,), daemon=True)
    t.start()
    time.sleep(0.5)  # 等待服务器就绪

    # 尝试 pywebview 启动
    try:
        import webview
        print("[BTC Widget] 使用 pywebview 桌面窗口")
        launch_with_pywebview(PORT)
    except ImportError:
        print("[BTC Widget] 未安装 pywebview，使用 tkinter 提示")
        launch_with_tkinter_fallback()
        # tkinter 退出后，服务器仍在后台，保持主线程存活
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n[BTC Widget] 已停止")
